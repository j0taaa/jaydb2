# JayDB2

Implementação em desenvolvimento do núcleo especificado em
[ESPECIFICACAO.md](ESPECIFICACAO.md). Os arquivos originais do contrato Bend
estão em `contrato/`, conferidos por SHA-256. As oito leis permanecem intactas.

**A conformidade do executável completo ainda não está demonstrada.** Há módulos
implementados e provas gerais verificadas; os bloqueios do backend e da ligação
ao ambiente real continuam sendo tratados. Este repositório ainda não deve ser
apresentado como uma versão completa do banco.

O trabalho provisório admite credenciais vazias ou duplicadas. Inicialização e
publicação exigem credenciais não vazias e únicas. As leis do administrador podem
impor condições adicionais aos prefixos. A autenticação usa o estado publicado
no início da chamada. Essa decisão está documentada no Markdown e nos testes.

O controlador `jaydb2.py` enquadra chamadas seriais por stdin/stdout. As operações,
decodificação, autenticação, interpretação incremental e preparação são módulos
Bend compilados para CPU e carregados no mesmo processo. Verificação e
compilação usam processos auxiliares; o observador de recursos em integração
também é contabilizado como parte do serviço. O estado publicado é um buffer privado em
RAM; o estado das chamadas não é fornecido ao verificador nem gravado nos
diretórios de compilação. A inicialização usa separadamente o seed do administrador
e sua prova de validade.
Código e certificado são verificados juntos, com os alvos gerados para o contexto
autenticado e os argumentos reais. O mesmo Book verificado segue para a emissão.

O núcleo prepara integralmente estado e resposta antes de uma única publicação.
Entrega ocorre depois; perder o canal depois da publicação não desfaz o estado.
Um consumidor que mantém o canal aberto precisa progredir para permitir a entrega;
não existe um prazo adicional de entrega escondido na implementação.

A medida de memória escolhida conta o backing adquirido e retido pelos processos
do serviço, incluindo ferramentas, bibliotecas, stacks e observador. Exclui a
memória interna do kernel, inclusive temporários de syscalls não entregues aos
processos. A contabilidade completa dessa medida ainda está em implementação.
RSS amostrado foi removido como justificativa de `limite`. A monitoração por
janela exige cobertura completa e preserva a origem do pico local; ela ainda
precisa ser conectada à chamada inteira e às construções nativas de campos.
O hook interno de conclusão já liga a proposta do controlador ao root C retido,
com fallback `limite` preparado e sem atribuição Python do estado. Esse caminho
exige um escopo completo e os módulos nativos com accounting; a entrada CLI
ainda não estabelece essas condições.

A fronteira privada de recepção conserva no C a quantidade efetivamente lida
antes de retornar ao Python. Uma interrupção não autoriza repetir uma leitura
de consumo incerto. A entrega também conserva a conclusão publicada quando um
sinal interrompe uma escrita parcial. Esses reparos passaram por uma
[revisão independente da versão V7](tests/reviews/completion7/independent/REPORT.md);
essa revisão não demonstra a entrada completa nem a medida de memória.

## Ambiente de desenvolvimento

O backend atual usa Linux x86_64, páginas de 4096 bytes, Clang 19, Python 3.12 e
Node 24.19+. As fontes do Bend 2.0.39 e o kernel BendTT são fixados por hash.
O serviço roda no thread principal, com a stack Linux expansível. A inicialização
confere o perfil selecionado e recusa opções de carregamento externo, como
`NODE_OPTIONS` e `LD_PRELOAD`, que acrescentariam componentes fora desse perfil.
Essas condições do host não restringem o fragmento Bend admitido.
Os helpers Python já usam a [inicialização isolada selecionada](tools/service/ISOLATED_STARTUP.md),
com `-I -S -B`, preservando seus argumentos e prazos. Para a entrada inicial,
o comando isolado deve ser escolhido antes de iniciar Python, dentro do
observador; o comando CLI de desenvolvimento abaixo ainda usa startup
ordinário. O capsule completo e sua estabilidade continuam pendentes. O
[ensaio anterior](tests/research/entry/ISOLATED_STARTUP-2026-10-29.md) conserva
os controles causais de banco e helper separadamente.

```sh
python3 tools/bootstrap.py --source /caminho/bend-2.0.39 --kernel /caminho/bendtt
python3 -m tools.service.build_loading .tools/service/loading.so
python3 -m tools.service.build_lifecycle .tools/service/lifecycle.so
node tools/admission/build-frontend.mjs --write-lock
node tools/verifier/build.mjs --write-lock
make verify
make test-host
make test-admission
make test-native
make test-integration
```

O bootstrap instala os artefatos em `.tools/`, sem instalar ferramentas globais.
O loader e o runtime de ciclo de vida são instalados antes do serviço. Seus recibos C
registram aquisição e liberação de bibliotecas; o shim fixo permanece no baseline
do processo. Não há compilação desses shims durante uma requisição. O segundo
registra a criação dos helpers, o retorno das chamadas C e a liberação dos buffers
de saída. Owners pendentes permanecem retidos e impedem a descarga do módulo.
Sem `--source`, baixa o arquivo oficial de fontes e confere o hash fixado. O
kernel precisa ser o artefato Linux fixado, já compilado; o bootstrap rejeita
substitutos. `tools/bend.py` instala separadamente a distribuição oficial usada
nos testes de prova, ou aceita `JAYDB_BEND` da versão correta.
O passo separado do verificador requer Lean 4.34.0 local. Ele verifica a
derivação com combustível parametrizado e produz o binário e o manifesto
fixados em `tools/verifier/verifier.lock.json`; o kernel original é preservado.

Exemplo de chamada do controlador, depois de resolver os bloqueios descritos:

```sh
python3 jaydb2.py --configuration examples/sem-observacoes/Configuration.bend \
  --seed examples/sem-observacoes/Seed.bend
```

Os imports da configuração registram seu fechamento público de bibliotecas
imutáveis, inclusive imports sem uso em `config()`. O módulo `Seed.bend` contém
o estado inicial e a prova exata `Requisitos.Valido(Configuration.config(), estado())`.
O seed permanece privado e não entra na identidade pública do ambiente.
A configuração deve usar `Environment.identidade()` como seu nome de ambiente.
A inicialização compara esse nome com a identidade realmente congelada, que
também inclui as fontes, o binário e o manifesto do verificador derivado.

`tools/client.py` codifica requisições e decodifica respostas canônicas:

```sh
python3 tools/client.py --codigo examples/sem-observacoes/Client.bend \
  --prova examples/sem-observacoes/ClientProof.bend --credencial demo
```

O comando escreve bytes enquadrados em stdout. `--decode` lê uma resposta de
stdin e imprime seu valor JSON. O exemplo instala uma lei proposicional que
proíbe observações; o programa certificado calcula uma soma recursiva e recusa
com o valor inteiro 6.

## Evidência e obrigações abertas

As provas e seus limites estão em [proof/README.md](proof/README.md); admissão e
backend têm documentação em [tools/admission/README.md](tools/admission/README.md)
e [native/README.md](native/README.md). Testes e hashes identificam o que foi
executado; não substituem uma prova da correspondência com o executável.

O backend agora representa naturais de forma compacta, com promoção para limbs
arbitrários; os valores públicos da configuração executam sem expansão unária.
O fluxo completo de recusa e sucesso foi testado com a lei proposicional do
primeiro exemplo. O exemplo `examples/credenciais/` também passou pela admissão,
compilação e execução reais: credencial vazia provisória reparada, leitura da
própria escrita, atualização de autenticação na chamada seguinte, descarte em
recusa/erro e conservação após falha de entrega.
As testemunhas de `src/Terminacao.bend` ajudam a demonstrar
término e não fornecem um contador ao runtime. `src/Livre.bend` prova segurança
dos percursos na configuração que escolhe explicitamente zero leis adicionais.

O transporte privado e o Codec têm provas gerais nos dois sentidos, incluindo
listas e registros arbitrariamente aninhados. Toda aceitação reconstrói os
bytes canônicos exatos; toda codificação representável é aceita dentro do
limite, inclusive quando seu tamanho é igual ao teto. O resultado do decoder
satisfaz a relação original `Interface.DecodificacaoCorreta`.
Continuam necessárias a eliminação das demais
restrições de representação, a contabilização completa dos recursos e a instância concreta de
`Interface.Ambiente` ligada ao controlador, ferramentas, runtime e canal. Somente
depois dessas ligações será possível afirmar `LAWS.Contrato(a,k)` para o serviço.
