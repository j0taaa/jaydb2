import * as child from "node:child_process";
import * as crypto from "node:crypto";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import * as B from "./bend.ts";
const NAT_MAX = 128;
let MODEL_FUEL = 1n << 22n;
let ADMISSION_DEADLINE = null;
let ADMISSION_SCHEMAS = [];
let ADMISSION_INSTANCES = [];
let ADMISSION_SOURCE_CLAIMS = new Map();
export class SafeResourceExhausted extends Error {
    code = "SAFE_MODEL_EXHAUSTED";
}
export class SafeDeadlineExceeded extends Error {
    code = "HOST_VERIFICATION_DEADLINE";
}
class AdmissionInstanceRequest extends Error {
    name;
    parameters;
    constructor(name, parameters){
        super("Closed template instance needed: " + name), this.name = name, this.parameters = parameters;
    }
}
function admission_deadline() {
    if (ADMISSION_DEADLINE !== null && process.hrtime.bigint() >= ADMISSION_DEADLINE) throw new SafeDeadlineExceeded("Host verification deadline expired during Safe elaboration");
}
const MODEL_DEPTH = 8;
const LEAN_VERSION = "4.34.0";
const QS = [
    "Q0",
    "Q1",
    "Q2"
];
const UT = {
    $: "Enu",
    ks: [
        "()"
    ]
};
const UV = {
    $: "Lab",
    k: "()"
};
class Scope_Error extends Error {
}
class Open_Error extends Scope_Error {
}
class Regroup extends Error {
    key;
    constructor(key){
        super(key), this.key = key;
    }
}
class Reroute extends Error {
}
function oos(why, E = Scope_Error) {
    throw new E(why);
}
function safe_book(book) {
    const n0 = Object.keys(book.tlds).length;
    const groups = new Map();
    const inst = new Map(Object.entries(book.tmps).flatMap(([k, is])=>[
            ...is
        ].map(([key, n])=>[
                n,
                [
                    k,
                    key.split("\n").map((a)=>B.term_higher(JSON.parse(a)))
                ]
            ])));
    for(let r = safe_pass(book, groups, inst);; r = safe_pass(book, groups, inst)){
        if (r !== null) {
            return r;
        }
        Object.keys(book.tlds).slice(n0).forEach((k)=>delete book.tlds[k]);
    }
}
function safe_pass(book, groups, inst) {
    const g0 = groups.size;
    const e = {
        book,
        mb: {
            ...book,
            tlds: Object.create(book.tlds)
        },
        out: [],
        names: new Map(),
        seen: new Set(),
        todo: [],
        taken: new Set(),
        fail: new Map(),
        log: [],
        groups,
        inst,
        stack: [],
        going: new Set(),
        grew: false,
        consts: new Map(),
        uses: new WeakMap()
    };
    const roots = [];
    for (const k of admission_roots(e)){
        const m = trail(e);
        try {
            roots.push([
                k,
                ...root_emit(e, k)
            ]);
        } catch (x) {
            if (!(x instanceof Scope_Error)) {
                throw x;
            }
            undo(e, m);
            const n = fresh(e, name_tt(k));
            put(e, e.fail, n, x.message);
            roots.push([
                k,
                [
                    n
                ],
                null
            ]);
        }
    }
    admission_source_links(e);
    for(let it = e.todo.pop(); it !== undefined; it = e.todo.pop()){
        item_try(e, it[0], it[1]);
    }
    if (e.grew || groups.size > g0 && [
        ...e.names.keys()
    ].some((key)=>key[0] !== "\t" && groups.has(key.split("\n")[0]))) {
        return null;
    }
    const bad = new Map(e.fail);
    for(let more = bad.size > 0; more;){
        more = false;
        for (const [k, T, v] of e.out){
            const r = bad.has(k) ? undefined : [
                ...o_refs(T),
                ...o_refs(v)
            ].find((r)=>bad.has(r));
            if (r !== undefined) {
                bad.set(k, "names " + B.name_key(r) + ", out of scope: " + (e.fail.get(r) ?? bad.get(r)));
                more = true;
            }
        }
    }
    e.out = e.out.filter(([k])=>!bad.has(k));
    const why = (n)=>bad.has(n) ? [
            bad.get(n)
        ] : [];
    const oos = roots.flatMap(([k, ns, top])=>{
        const ws = ns.flatMap(why);
        const all = ws.length > 0 ? ws : top !== null ? why(top) : ns.length === 0 ? [
            "no kernel def"
        ] : [];
        return [
            ...new Set(all)
        ].map((w)=>[
                k,
                w
            ]);
    });
    return {
        text: book_show(e),
        oos
    };
}
function root_emit(e, k) {
    admission_deadline();
    const tld = e.book.tlds[k];
    if (tld.$ === "Def" && tld.x > 0) return admission_schema(e, k);
    const ns = [];
    let G;
    let ps = [];
    const kc = new Map();
    const pick = tld.$ === "Def" && tld.x > 0 ? inst_pick(e, k) : null;
    const col = (v)=>kc.get(v) ?? kc.set(v, term(e, scope_nil(), v, false)).get(v);
    const go = (T, cs, d)=>{
        const j = cs.length;
        const F = j === tld.n ? null : B.term_wnf(e.book, T);
        if (F?.$ !== "All") {
            ns.push(item_try(e, k, cs));
            const x = {
                $: "Ref",
                k: ns[ns.length - 1]
            };
            return G == null ? x : {
                $: "Ann",
                x,
                T: ps.reduce((f, [q], j)=>({
                        $: "App",
                        q,
                        f,
                        x: col(cs[j])
                    }), {
                    $: "Var",
                    l: 0
                })
            };
        }
        const at = (v, d1 = d)=>go(F.B(v ?? B.Var(F.k, j)), [
                ...cs,
                v
            ], d1);
        if (tld.$ !== "Def" || j >= tld.x) {
            return at(null);
        }
        const A = B.term_wnf(e.book, F.A);
        const adt = A.$ === "ADT" && A.x.length === 0 ? e.book.tlds[A.k] : null;
        const vs = A.$ === "Qnt" ? [
            B.None(),
            B.Lone(),
            B.Many()
        ].map((q)=>B.Qua(q)) : adt !== null && adt.c.every((c)=>B.term_wnf(e.book, c.T).$ !== "All") ? adt.c.map((c)=>B.Ctr(c.k, [])) : null;
        if (vs !== null) {
            if (G === undefined) {
                G = null;
                const m = trail(e);
                try {
                    const t = tele_open(e, scope_nil(), tld.T, [], tld.x);
                    const b = term(e, t.s, t.T, false);
                    G = {
                        $: "Ann",
                        x: lams(e, t.ps, b),
                        T: alls(t.ps, {
                            $: "Typ",
                            q: {
                                $: "Lab",
                                k: "Q1"
                            }
                        })
                    };
                    ps = t.ps;
                } catch (x) {
                    if (!(x instanceof Open_Error)) {
                        throw x;
                    }
                    undo(e, m);
                }
            }
            const hs = vs.map((v)=>({
                    $: "Let",
                    q: 0,
                    l: d,
                    v: at(v, d + 1),
                    f: UV
                }));
            const M = adt === null ? mats(QS, (i)=>hs[i]) : {
                $: "Prj",
                h: mats(adt.c.map((c)=>name_tt(c.k)), (i)=>unit(hs[i]))
            };
            return {
                $: "Ann",
                x: M,
                T: {
                    $: "All",
                    q: 1,
                    l: d,
                    A: term(e, scope_nil(), A, false),
                    B: UT
                }
            };
        }
        if (mentions(B.term_lower(F.A, j), (i)=>i >= 0 && i < j)) {
            oos("a specialized parameter whose type names a parameter");
        }
        const f = pick === null ? null : fit(e, k, pick[j], F.A);
        const key = String(j) + "\n" + B.term_key(B.term_lower(F.A)) + "\n" + (f === null ? "" : B.term_key(B.term_lower(f)));
        const kept = e.consts.get(key);
        if (kept !== undefined) {
            return at(B.Ref(kept));
        }
        let c = k + "~" + F.k;
        while(e.book.tlds[c] !== undefined){
            c += "~";
        }
        const m = f ?? model(e, F.A);
        const def = {
            $: "Def",
            n: 0,
            x: 0,
            T: F.A,
            v: null
        };
        e.book.tlds[c] = def;
        if (m !== null) {
            e.mb.tlds[c] = {
                ...def,
                v: m
            };
        }
        e.consts.set(key, c);
        return at(B.Ref(c));
    };
    const h = go(tld.T, [], 2);
    if (G === undefined) {
        return [
            ns,
            null
        ];
    }
    const v = {
        $: "Let",
        q: 0,
        l: 1,
        v: h,
        f: UV
    };
    const n = fresh(e, name_tt(k));
    e.out.push([
        n,
        UT,
        G === null ? v : {
            $: "Let",
            q: 0,
            l: 0,
            v: G,
            f: v
        },
        false
    ]);
    return [
        ns,
        n
    ];
}
function item_try(e, k, cols) {
    try {
        return item_ref(e, k, cols, true);
    } catch (x) {
        if (x instanceof Reroute) {
            return item_try(e, k, cols);
        }
        if (!(x instanceof Scope_Error)) {
            throw x;
        }
        return e.names.get(item_key(k, cols));
    }
}
function item_key(k, cols) {
    return [
        k,
        ...cols.flatMap((v)=>v === null ? [] : [
                B.term_key(B.term_lower(v))
            ])
    ].join("\n");
}
function item_ref(e, k, cols, live) {
    const key = item_key(k, cols);
    const m = live && !e.seen.has(key) ? trail(e) : null;
    let n = e.names.get(key);
    if (n === undefined) {
        const tag = cols.flatMap((v)=>v === null ? [] : [
                v.$ === "Qua" ? String(quant(v.q)) : "v"
            ]).join("");
        n = fresh(e, name_tt(k[0] === "\t" ? k.slice(1) + ".group" : k) + (tag !== "" ? ".q" + tag : ""));
        put(e, e.names, key, n);
        e.todo.push([
            k,
            cols
        ]);
    }
    const why = e.fail.get(n);
    if (why !== undefined && live) {
        oos(why);
    }
    if (m !== null) {
        put(e, e.seen, key);
        e.stack.push(key);
        e.going.add(key);
        try {
            item_emit(e, k, cols, n);
        } catch (x) {
            if (x instanceof Scope_Error) {
                put(e, e.fail, n, x.message);
            }
            if (x instanceof Regroup && x.key === key) {
                undo(e, m);
                throw new Reroute();
            }
            throw x;
        } finally{
            e.stack.pop();
            e.going.delete(key);
        }
    } else if (live && e.going.has(key) && e.stack[e.stack.length - 1] !== key) {
        regroup(e, key);
    }
    return n;
}
function item_emit(e, k, cols, n) {
    if (k[0] === "\t") {
        return group_emit(e, group_of(e, k.slice(1)), cols, n);
    }
    const tld = e.book.tlds[k];
    if (tld === undefined) {
        oos("an unknown name " + B.name_key(k));
    }
    if (tld.$ === "ADT") {
        return adt_emit(e, cols, n, tld);
    }
    if (tld.u === true) {
        oos("uses " + (tld.b === true ? "base's" : "the") + " @unsafe def " + B.name_key(k));
    }
    def_emit(e, k, cols, n, tld);
}
function def_emit(e, k, cols, n, tld) {
    const T = B.tele_fill(e.book, tld.T, cols.slice(0, tld.x), B.ctx_nil());
    const t = tld.e !== undefined ? null : (Object.hasOwn(e.mb.tlds, k) ? e.mb.tlds[k].v : model(e, T)) ?? oos("no model for " + (tld.i === undefined ? "" : (tld.b === true ? "base's" : "the") + " foreign def ") + B.name_key(k));
    const s = {
        ...scope_nil(),
        self: n
    };
    const To = term(e, s, T, false);
    e.out.push([
        n,
        To,
        t === null ? arm(e, s, k, cols, []) : tree(e, s, t, []),
        t !== null
    ]);
}
function adt_emit(e, cols, n, tld) {
    const { s, ps, xs, T } = tele_open(e, scope_nil(), tld.T, cols, tld.n);
    const K = B.term_wnf(e.book, T);
    if (K.$ !== "Typ") {
        oos("a datatype kind");
    }
    const G = term(e, s, K, false);
    const am = fresh(e, n + ".arms");
    const t = s.D;
    const fs = (c)=>alls(tele_open(e, s, B.tele_fill(e.book, c.T, xs, B.ctx_nil()), [], Infinity).ps, UT, "Sig");
    const ks = tld.c.map((c)=>name_tt(c.k));
    const arms = mats(ks, (i)=>fs(tld.c[i]));
    const Enu = {
        $: "Enu",
        ks
    };
    e.out.push([
        am,
        alls(ps, {
            $: "All",
            q: 1,
            l: t,
            A: Enu,
            B: G
        }),
        lams(e, ps, arms),
        false
    ]);
    const at = (k)=>ps.reduce((f, [q, l])=>({
                $: "App",
                q,
                f,
                x: {
                    $: "Var",
                    l
                }
            }), {
            $: "Ref",
            k
        });
    e.out.push([
        n,
        alls(ps, G),
        lams(e, ps, {
            $: "Sig",
            q: 1,
            l: t,
            A: Enu,
            B: {
                $: "App",
                q: 1,
                f: at(am),
                x: {
                    $: "Var",
                    l: t
                }
            }
        }),
        false
    ]);
    if (tld.c.length === 0) {
        e.out.push([
            fresh(e, n + ".efq"),
            alls(ps, {
                $: "All",
                q: 1,
                l: t,
                A: at(n),
                B: {
                    $: "Enu",
                    ks: []
                }
            }),
            lams(e, ps, {
                $: "Prj",
                h: {
                    $: "Efq"
                }
            }),
            false
        ]);
    }
}
function tele_open(e, s, T, cols, n) {
    const r = {
        s,
        ps: [],
        xs: [],
        T
    };
    for(let j = 0; j < n; j++){
        const F = B.term_wnf(e.book, r.T);
        if (F.$ !== "All") {
            break;
        }
        const q = quant(F.q);
        if (cols[j] == null) {
            r.ps.push([
                q,
                r.s.D,
                term(e, r.s, F.A, false)
            ]);
            r.s = scope_kq(scope_bind(r.s, {
                $: "Var",
                l: r.s.D
            }, F.A, true), r.s.D, q);
        }
        r.xs.push(cols[j] ?? B.Var(F.k, r.s.d - 1));
        r.T = F.B(r.xs[j]);
    }
    return r;
}
function spec_val(e, s, x) {
    return closed_val(e, s, x) ?? oos("a template argument that depends on a run-time value", Open_Error);
}
function closed_val(e, s, x) {
    const v = B.term_snf(e.book, subst(x, s.d, (o)=>o.$ === "Var" && o.i >= 0 && o.i < s.d ? s.c[o.i]?.v ?? B.Var(o.k, o.i) : undefined));
    return mentions(B.term_lower(v, s.d), (i)=>i >= 0 && i < s.d) ? null : v;
}
function subst(t, d, f) {
    const go = (u)=>{
        if (typeof u !== "object" || u === null) {
            return u;
        }
        const o = u;
        const v = f(o);
        return v !== undefined ? B.Var(o.k, -1, undefined, v) : Array.isArray(u) ? u.map(go) : Object.fromEntries(Object.entries(o).map(([k, x])=>[
                k,
                k === "s" ? x : go(x)
            ]));
    };
    return B.term_higher(go(B.term_lower(t, d)));
}
function model(e, T) {
    return model_by(e, T, false) ?? model_by(e, T, true);
}
function inst_pick(e, k) {
    const fits = (T, [x, ...xs])=>{
        if (x === undefined) {
            return true;
        }
        const F = B.term_wnf(e.mb, T);
        return F.$ === "All" && fit(e, k, x, F.A) !== null && fits(F.B(x), xs);
    };
    return [
        ...e.inst.values()
    ].find(([t, xs])=>t === k && fits(e.book.tlds[k].T, xs))?.[1] ?? null;
}
function fit(e, k, x, T) {
    try {
        return B.term_higher(B.term_check(e.mb, {
            t: B.Ref(k),
            n: 0,
            def: k,
            qs: []
        }, x, B.Lone(), T, B.ctx_nil(), 0).tm);
    } catch (err) {
        if (err.$ !== "Err") {
            throw err;
        }
        return null;
    }
}
function model_by(e, T, proj) {
    const probe = {
        left: MODEL_FUEL,
        depth: MODEL_DEPTH,
        cut: true
    };
    let m = null;
    for(; probe.cut && probe.left > 0n; probe.depth *= 2){
        probe.cut = false;
        const v = model_at(e, T, 0, [], [], proj, probe);
        m = probe.cut ? m ?? v : v;
    }
    if (probe.cut && probe.left <= 0n) throw new SafeResourceExhausted("Safe model budget exhausted");
    return m;
}
function model_key(F, d) {
    const at = (i)=>typeof i === "number" && i >= d ? "^" + (i - d) : i;
    return JSON.stringify(B.term_lower(F, d), (k, v)=>k === "s" ? undefined : k !== "i" ? v : Array.isArray(v) ? v.map(at) : at(v));
}
function model_at(e, T, d, path, hs, proj, probe) {
    admission_deadline();
    if (path.length + d > probe.depth || probe.left <= 0n) {
        probe.cut = true;
        return null;
    }
    probe.left -= 1n;
    const F = B.term_wnf(e.mb, T);
    const hyp = ()=>hs.find(([, A])=>B.term_compare("EQ", e.mb, A, F, d))?.[0] ?? null;
    switch(F.$){
        case "Typ":
            {
                const tld = e.mb.tlds["Unit"];
                return tld?.$ === "ADT" && tld.n === 0 ? B.ADT("Unit", []) : null;
            }
        case "All":
            {
                const x = B.Var(F.k, d);
                const t = model_at(e, F.B(x), d + 1, path, F.q.$ === "None" ? hs : [
                    ...hs,
                    [
                        x,
                        F.A
                    ]
                ], proj, probe);
                return t === null ? null : B.Ann(B.Lam(F.k, d, (v)=>subst(t, d + 1, (o)=>o.$ !== "Var" || o.i > d ? undefined : o.i === d ? v : B.Var(o.k, o.i))), F);
            }
        case "ADT":
            {
                const key = model_key(F, d);
                probe.left -= BigInt(key.length);
                const tld = e.mb.tlds[F.k];
                if (tld?.$ !== "ADT") {
                    return hyp();
                }
                const h = proj ? hyp() : null;
                for (const c of path.includes(key) || h !== null ? [] : tld.c.filter((c)=>!F.r.includes(c.k))){
                    const xs = [];
                    let U = B.term_wnf(e.mb, B.tele_fill(e.mb, c.T, F.x, B.ctx_nil()));
                    let x = null;
                    while(U.$ === "All" && (x = model_at(e, U.A, d, [
                        ...path,
                        key
                    ], [], proj, probe)) !== null){
                        xs.push(x);
                        U = B.term_wnf(e.mb, U.B(x));
                    }
                    if (U.$ !== "All") {
                        return B.Ann(B.Ctr(c.k, xs), F);
                    }
                }
                return hyp();
            }
        case "Eql":
            {
                return B.term_compare("EQ", e.mb, F.a, F.b, d) ? B.Ann(B.Rfl(), F) : null;
            }
        default:
            {
                return hyp();
            }
    }
}
function fresh(e, n) {
    let k = n;
    for(let i = 1; e.taken.has(k); i++){
        k = n + "_" + String(i);
    }
    put(e, e.taken, k);
    return k;
}
function name_tt(k) {
    return B.name_key(k).replace(/[^A-Za-z0-9_.]|^[.0-9]/g, (c)=>"_" + (c.codePointAt(0) ?? 0).toString(16) + "_");
}
function quant(q) {
    return q.$ === "None" ? 0 : q.$ === "Lone" ? 1 : 2;
}
function scope_nil() {
    return {
        c: [],
        d: 0,
        D: 0,
        cols: [],
        self: "",
        empty: [],
        sub: false,
        kq: [],
        tags: [],
        dry: false,
        again: false
    };
}
function scope_bind(s, o, T, kb, v) {
    const c = s.c.slice();
    c[s.d] = {
        o,
        T,
        v
    };
    return {
        ...s,
        c,
        d: s.d + 1,
        D: s.D + (kb ? 1 : 0)
    };
}
function scope_hide(s) {
    return {
        ...s,
        D: s.D + 1
    };
}
function scope_kq(s, l, q) {
    const kq = s.kq.slice();
    kq[l] = q;
    return {
        ...s,
        kq
    };
}
function scope_move(s, a, b) {
    const mv = (o)=>o.$ === "Var" ? o.l === a ? {
            $: "Var",
            l: b
        } : o : Object.fromEntries(Object.entries(o).map(([k, v])=>[
                k,
                is_o(v) ? mv(v) : v
            ]));
    return {
        ...s,
        c: s.c.map((x)=>x === undefined ? x : {
                ...x,
                o: mv(x.o)
            }),
        empty: s.empty.map(mv),
        tags: s.tags.flatMap((t)=>t === a ? [
                t,
                b
            ] : [
                t
            ])
    };
}
function convoy_bind(e, s, cv, t, fs) {
    if (cv.length === 0) {
        return typeof t === "function" ? t(s) : tree(e, s, t, fs);
    }
    const l = s.D;
    const q = s.kq[cv[0]] ?? 1;
    const f = convoy_bind(e, scope_move(scope_kq(scope_hide(s), l, q), cv[0], l), cv.slice(1), t, fs);
    return lams(e, [
        [
            q,
            l
        ]
    ], f);
}
function open(t) {
    let T = null;
    let x = B.term_force(t);
    while(x.$ === "Ann"){
        T ??= B.term_force(x.T);
        x = B.term_force(x.x);
    }
    return [
        x,
        T
    ];
}
function unapply(t) {
    const xs = [];
    let [x] = open(t);
    let h = t;
    while(x.$ === "App"){
        xs.push(x.x);
        h = x.f;
        [x] = open(x.f);
    }
    return [
        h,
        xs.reverse()
    ];
}
function tree(e, s, t, fs) {
    const top = fs[fs.length - 1];
    if (top !== undefined && top.n === 0) {
        return unit(convoy_bind(e, s, top.cv, t, fs.slice(0, -1)));
    }
    const [x, T] = open(t);
    const all = all_of(e, T);
    const v = top === undefined ? s.cols[0] ?? null : null;
    if (v !== null && x.$ === "Lam") {
        const s2 = scope_bind({
            ...s,
            cols: s.cols.slice(1)
        }, {
            $: "Efq"
        }, all?.A ?? null, false, v);
        return tree(e, s2, x.f(B.Var(x.k, s.d)), fs);
    }
    if (v !== null && (x.$ === "Mat" || x.$ === "Efq")) {
        const [arm, vs] = pick(e, x, v);
        return tree(e, {
            ...s,
            cols: [
                ...vs,
                ...s.cols.slice(1)
            ]
        }, arm, fs);
    }
    if (x.$ !== "Lam" && x.$ !== "Mat" && x.$ !== "Efq") {
        if (all !== null) {
            return tree(e, s, eta(t, all), fs);
        }
        return top === undefined ? term(e, s, t, true) : oos("a match arm with no known type");
    }
    const fs2 = top === undefined ? fs : [
        ...fs.slice(0, -1),
        {
            ...top,
            n: top.n - 1
        }
    ];
    const wrap = (o)=>top === undefined ? o : {
            $: "Prj",
            h: o
        };
    const s1 = top === undefined ? {
        ...s,
        cols: s.cols.slice(1)
    } : s;
    if (x.$ === "Lam") {
        const l = s.D;
        let q = all === null ? 1 : quant(all.q);
        let s2 = scope_kq(scope_bind(s1, {
            $: "Var",
            l
        }, all?.A ?? null, true), l, q);
        if (q > 0 && all !== null && no_ctr(e, all.A)) {
            s2 = {
                ...s2,
                empty: [
                    ...s2.empty,
                    {
                        $: "App",
                        q: 1,
                        f: {
                            $: "Prj",
                            h: {
                                $: "Efq"
                            }
                        },
                        x: {
                            $: "Var",
                            l
                        }
                    }
                ]
            };
        }
        const y = B.Var(x.k, s.d);
        const f = tree(e, s2, typed(x.f(y), all?.B(y)), fs2);
        if (!e.admissionStage && q === 1 && uses(e, f, l) > 1) {
            const A = all === null ? null : B.term_wnf(e.book, all.A);
            if (all !== null && kind(e, s, all.A) === 1 && A.$ !== "Eql" && kind(e, s, A) !== 2) {
                return tree(e, s, rebuild(e, s, x, all) ?? oos("a λ that uses a variable twice, of a type whose fields are not Data (a ~ argument)"), fs);
            }
            q = 2;
        }
        return wrap({
            $: "Lam",
            q,
            l,
            f
        });
    }
    const q = all === null ? 1 : quant(all.q);
    const mat = (cv, dry)=>{
        if (cv.length === 0) {
            return wrap({
                $: "Prj",
                h: swi(e, {
                    ...s1,
                    dry
                }, x, T, fs2, [])
            });
        }
        const l = s.D;
        const sw = swi(e, scope_kq(scope_hide({
            ...s1,
            dry,
            again: true
        }), l, q), x, T, fs2, cv);
        const app = cv.reduce((f, y)=>({
                $: "App",
                q: s.kq[y] ?? 1,
                f,
                x: {
                    $: "Var",
                    l: y
                }
            }), {
            $: "App",
            q,
            f: {
                $: "Prj",
                h: sw
            },
            x: {
                $: "Var",
                l
            }
        });
        return wrap({
            $: "Lam",
            q,
            l,
            f: app
        });
    };
    const o = mat([], s.dry || s.again);
    const us = o_uses(e, o);
    const use = (l)=>us.get(l) ?? 0;
    const data = (l)=>s.c.some((b)=>b?.o.$ === "Var" && b.o.l === l && b.T !== null && kind(e, s, b.T) === 2);
    const cv0 = s.kq.flatMap((k, l)=>k === 1 && l < s.D && use(l) > 1 && !data(l) ? [
            l
        ] : []);
    const cv1 = [
        ...new Set(cv0.flatMap((l)=>s.tags.includes(l) ? [
                l,
                l + 1
            ] : s.tags.includes(l - 1) ? [
                l - 1,
                l
            ] : [
                l
            ]))
    ];
    const cv = s.c.reduce((vs, b, i)=>{
        if (vs.length === 0 || b === undefined || b.T === null) {
            return vs;
        }
        const ls = [
            ...o_uses(e, b.o).keys()
        ].filter((l)=>!vs.includes(l));
        const js = ls.some((l)=>us.has(l)) ? s.c.flatMap((x, j)=>j < i && x !== undefined && [
                ...o_uses(e, x.o).keys()
            ].some((l)=>vs.includes(l)) ? [
                j
            ] : []) : [];
        return js.length > 0 && mentions(B.term_lower(b.T, s.d), (k)=>js.includes(k)) ? [
            ...vs,
            ...ls
        ] : vs;
    }, cv1).sort((a, b)=>a - b);
    if (s.dry) {
        return [
            ...Array(s.D).keys()
        ].filter((l)=>us.has(l)).reduce((f, l)=>({
                $: "App",
                q: use(l) > 0 ? 1 : 0,
                f,
                x: {
                    $: "Var",
                    l
                }
            }), {
            $: "Efq"
        });
    }
    if (cv.length === 0 && !s.again) {
        return o;
    }
    return mat(cv, false);
}
function swi(e, s, t, T, fs, cv) {
    const [x, U] = open(t);
    const all = all_of(e, U ?? T);
    switch(x.$){
        case "Efq":
            {
                if (all === null || no_ctr(e, all.A) || s.empty.length === 0) {
                    return {
                        $: "Efq"
                    };
                }
                const q = quant(all.q);
                const f = convoy_bind(e, scope_hide(scope_hide(s)), cv, (s2)=>s2.empty[0], fs);
                return {
                    $: "Lam",
                    q,
                    l: s.D,
                    f: {
                        $: "Lam",
                        q,
                        l: s.D + 1,
                        f
                    }
                };
            }
        case "Mat":
            {
                const ctr = e.book.ctrs[x.k];
                if (ctr === undefined) {
                    oos("an unknown constructor " + B.name_key(x.k));
                }
                const [hT, mT] = goals(e, all, ctr);
                const h = tree(e, s, typed(x.h, hT), [
                    ...fs,
                    {
                        n: ctr.n,
                        cv
                    }
                ]);
                const dead = mT?.$ === "All" && no_ctr(e, mT.A) && x.m.$ !== "Mat";
                const m = swi(e, s, dead ? B.Efq() : x.m, mT, fs, cv);
                return {
                    $: "Mat",
                    k: name_tt(x.k),
                    h,
                    m
                };
            }
        default:
            {
                if (all === null) {
                    return oos("a default arm with no known type");
                }
                const q = quant(all.q);
                const [lt, la] = [
                    s.D,
                    s.D + 1
                ];
                const s2 = scope_hide(scope_hide(s));
                const f = x.$ === "Lam" ? x : open(eta(t, all))[0];
                const pair = {
                    $: "Tup",
                    q: 1,
                    a: {
                        $: "Var",
                        l: lt
                    },
                    b: {
                        $: "Var",
                        l: la
                    }
                };
                const s2e = no_ctr(e, all.A) ? {
                    ...s2,
                    empty: [
                        ...s2.empty,
                        {
                            $: "App",
                            q: 1,
                            f: {
                                $: "Efq"
                            },
                            x: {
                                $: "Var",
                                l: lt
                            }
                        }
                    ]
                } : s2;
                const s3 = scope_kq(scope_kq({
                    ...s2e,
                    tags: [
                        ...s2e.tags,
                        lt
                    ]
                }, lt, q), la, q);
                const y = B.Var(f.k, s.d);
                const body = convoy_bind(e, scope_bind(s3, pair, all.A, false), cv, typed(f.f(y), all.B(y)), fs);
                const r2 = !e.admissionStage && (uses(e, body, lt) > 1 || uses(e, body, la) > 1) ? 2 : q;
                return {
                    $: "Lam",
                    q: r2,
                    l: lt,
                    f: {
                        $: "Lam",
                        q: r2,
                        l: la,
                        f: body
                    }
                };
            }
    }
}
function goals(e, all, c) {
    const A = all === null ? null : B.term_wnf(e.book, all.A);
    if (all === null || A?.$ !== "ADT") {
        return [
            null,
            null
        ];
    }
    const go = (U, xs)=>{
        const F = B.term_wnf(e.book, U);
        return F.$ === "All" ? B.All(F.q, F.k, F.i, F.A, (x)=>go(F.B(x), [
                ...xs,
                x
            ])) : all.B(B.Ctr(c.k, xs));
    };
    return [
        go(B.tele_fill(e.book, c.T, A.x, B.ctx_nil()), []),
        {
            ...all,
            A: {
                ...A,
                r: [
                    ...A.r,
                    c.k
                ]
            }
        }
    ];
}
function typed(t, T) {
    return T == null || open(t)[1] !== null ? t : B.Ann(t, T);
}
function pick(e, t, v) {
    const w = B.term_wnf(e.book, v);
    const c = w.$ === "Lit" ? B.term_higher(B.lit_step(w)) : w;
    let [m] = open(t);
    while(m.$ === "Mat" && c.$ === "Ctr" && m.k !== c.k){
        [m] = open(m.m);
    }
    if (c.$ !== "Ctr" || m.$ === "Efq") {
        return oos("a specialized argument that is not a constructor");
    }
    return m.$ === "Mat" ? [
        m.h,
        c.x
    ] : [
        m,
        [
            c
        ]
    ];
}
function rebuild(e, s, x, all) {
    const F = B.term_wnf(e.book, all.A);
    if (F.$ !== "ADT") {
        return null;
    }
    const data = (U)=>{
        const G = B.term_wnf(e.book, U);
        return G.$ !== "All" || kind(e, s, B.term_wnf(e.book, G.A)) === 2 && data(G.B(B.Var(G.k, -1)));
    };
    const arm = (k, U, xs)=>{
        const G = B.term_wnf(e.book, U);
        return G.$ !== "All" ? x.f(B.Ann(B.Ctr(k, xs), F)) : B.Lam(G.k, 0, (v)=>arm(k, G.B(v), [
                ...xs,
                v
            ]));
    };
    const cs = e.book.tlds[F.k].c.filter((c)=>!F.r.includes(c.k)).map((c)=>[
            c.k,
            B.tele_fill(e.book, c.T, F.x, B.ctx_nil())
        ]);
    return cs.every(([, U])=>data(U)) ? B.Ann(cs.reduceRight((m, [k, U])=>B.Mat(k, arm(k, U, []), m), B.Efq()), all) : null;
}
function all_of(e, T) {
    const G = T === null ? null : B.term_wnf(e.book, T);
    return G?.$ === "All" ? G : null;
}
function eta(t, all) {
    return B.Ann(B.Lam(all.k, 0, (y)=>B.Ann(B.App(t, y), all.B(y))), all);
}
function mentions(t, p) {
    if (typeof t !== "object" || t === null) {
        return false;
    }
    const o = t;
    if (o.$ === "Var" && p(o.i)) {
        return true;
    }
    return Object.entries(o).some(([k, v])=>k !== "s" && mentions(v, p));
}
function no_ctr(e, T) {
    const x = B.term_wnf(e.book, T);
    const tld = x.$ === "ADT" ? e.book.tlds[x.k] : undefined;
    return x.$ === "ADT" && tld?.$ === "ADT" && tld.c.every((c)=>x.r.includes(c.k));
}
function kind(e, s, T) {
    const [x] = open(T);
    const [h, xs] = x.$ === "ADT" ? [
        x,
        x.x
    ] : unapply(x);
    const [f] = open(h);
    const tld = f.$ === "ADT" || f.$ === "Ref" ? e.book.tlds[f.k] : undefined;
    if (tld === undefined) {
        return null;
    }
    try {
        const K = B.term_wnf(e.book, B.tele_fill(e.book, tld.T, xs, B.ctx_nil()));
        const g = K.$ === "Typ" ? closed_val(e, s, K.g) : null;
        return g === null ? null : g.$ === "Qua" && g.q.$ === "Many" ? 2 : 1;
    } catch  {
        return null;
    }
}
function term(e, s0, t, live) {
    if (e.admissionStage && !live) {
        const annotation = open(t)[1];
        t = typed(B.term_snf(e.book, t), annotation);
    }
    const [x, T] = open(t);
    const s = s0.sub && x.$ !== "Ctr" && x.$ !== "Lit" ? {
        ...s0,
        sub: false
    } : s0;
    switch(x.$){
        case "Var":
            {
                const b = s.c[x.i];
                if (b === undefined) {
                    oos("a free variable " + x.k);
                }
                return b.v !== undefined ? term(e, s0, typed(b.v, b.T), live) : b.o;
            }
        case "Ref":
        case "App":
            {
                return spine(e, s, t, live);
            }
        case "ADT":
            {
                const tld = e.book.tlds[x.k];
                if (tld?.$ !== "ADT") {
                    oos("an unknown datatype " + B.name_key(x.k));
                }
                return args(e, s, x.k, tld.T, x.x, live);
            }
        case "Typ":
            {
                return {
                    $: "Typ",
                    q: term(e, s, x.g, false)
                };
            }
        case "All":
            {
                const l = s.D;
                const A = term(e, s, x.A, false);
                const Bo = term(e, scope_bind(s, {
                    $: "Var",
                    l
                }, x.A, true), x.B(B.Var(x.k, s.d)), false);
                return {
                    $: "All",
                    q: quant(x.q),
                    l,
                    A,
                    B: Bo
                };
            }
        case "Lam":
        case "Mat":
        case "Efq":
            {
                return tree(e, {
                    ...s,
                    cols: []
                }, t, []);
            }
        case "Let":
            {
                return let_term(e, s, x, live);
            }
        case "Ctr":
            {
                return ctr_term(e, s, x, T, live);
            }
        case "Lit":
            {
                if (x.k === "String" && x.v.length > 64 && e.book.tlds.String?.b === true && e.book.tlds["String.append"]?.b === true) {
                    let at = Math.floor(x.v.length / 2);
                    const previous = x.v.charCodeAt(at - 1), current = x.v.charCodeAt(at);
                    if (previous >= 0xd800 && previous <= 0xdbff && current >= 0xdc00 && current <= 0xdfff) at++;
                    const joined = B.App(B.App(B.Ref("String.append"), B.Lit("String", x.v.slice(0, at))), B.Lit("String", x.v.slice(at)));
                    return term(e, s, joined, live);
                }
                if (x.k === "Nat" && x.v > NAT_MAX && e.book.tlds.Nat?.b === true) {
                    const [q, r] = [
                        Math.floor(x.v / NAT_MAX),
                        x.v % NAT_MAX
                    ];
                    const mul = B.App(B.App(B.Ref("Nat.mul"), B.Lit("Nat", q)), B.Lit("Nat", NAT_MAX));
                    return term(e, s, B.App(B.App(B.Ref("Nat.add"), mul), B.Lit("Nat", r)), live);
                }
                return term(e, s, B.term_higher(B.lit_step(x)), live);
            }
        case "Eql":
            {
                return {
                    $: "Eql",
                    a: arg_term(e, s, x.a, x.T, false),
                    b: arg_term(e, s, x.b, x.T, false),
                    T: term(e, s, x.T, false)
                };
            }
        case "Rfl":
            {
                return {
                    $: "Rfl"
                };
            }
        case "Rwt":
            {
                return rwt_term(e, s, x, live);
            }
        case "Qnt":
            {
                return {
                    $: "Enu",
                    ks: QS
                };
            }
        case "Qua":
            {
                return {
                    $: "Lab",
                    k: QS[quant(x.q)]
                };
            }
        case "Min":
            {
                return {
                    $: "Min",
                    a: term(e, s, x.a, live),
                    b: term(e, s, x.b, live)
                };
            }
        case "Hol":
            {
                return oos("a hole");
            }
        default:
            {
                return oos("a " + x.$ + " term");
            }
    }
}
function spine(e, s, t, live) {
    const [h, xs] = unapply(t);
    const [f, T] = open(h);
    const stage = e.admissionStage;
    if (stage && f.$ === "Ref") {
        const bound = stage.refs.get(f.k);
        if (bound !== undefined) return args(e, s, bound.o, bound.T, xs, live);
        const inst = e.inst.get(f.k);
        const name = inst?.[0] ?? f.k;
        const header = stage.refs.get(name) ?? stage.header(name);
        if (header !== undefined) return args(e, s, header.o, header.T, [
            ...inst?.[1] ?? [],
            ...xs
        ], live);
    }
    if (f.$ === "Ref" && e.inst.has(f.k)) {
        const concrete = e.book.tlds[f.k];
        if (concrete?.$ === "Def" && concrete.x === 0) return args(e, s, f.k, concrete.T, xs, live);
    }
    if (f.$ !== "Ref") {
        const U = f.$ === "Var" ? s.c[f.i]?.T ?? null : T;
        const o = term(e, s, h, live);
        return args(e, s, inferable(o) ? o : {
            $: "Ann",
            x: o,
            T: term(e, s, U ?? oos("an application with no known head type"), false)
        }, U, xs, live);
    }
    const g = e.inst.get(f.k);
    const [k, ys] = g === undefined ? [
        f.k,
        xs
    ] : [
        g[0],
        [
            ...g[1],
            ...xs
        ]
    ];
    const tld = e.book.tlds[k] ?? oos("an unknown name " + B.name_key(k));
    if (tld.$ === "Def" && ys.length < tld.x) {
        oos("a template " + B.name_key(k) + " short of its ~ arguments");
    }
    return args(e, s, k, tld.T, ys, live);
}
function args(e, s, k, T, xs, live) {
    const tld = typeof k === "string" ? e.book.tlds[k] : null;
    const nx = tld?.$ === "Def" ? tld.x : 0;
    if (nx > 0 && xs.length >= nx) {
        const prefix = xs.slice(0, nx).map((x)=>{
            const value = subst(x, s.d, (o)=>o.$ === "Var" && o.i >= 0 && o.i < s.d ? s.c[o.i]?.v ?? B.Var(o.k, o.i) : undefined);
            return admission_open_argument(e, s, value) ? null : value;
        });
        if (prefix.every((x)=>x !== null)) {
            const name = B.admission_instance(e.book, k, prefix);
            const concrete = name === undefined ? undefined : e.book.tlds[name];
            if (concrete?.$ === "Def" && concrete.x === 0) return args(e, s, name, concrete.T, xs.slice(nx), live);
            throw new AdmissionInstanceRequest(k, prefix);
        }
        if (!live) {
            const normal = xs.slice(0, nx).map((x)=>closed_val(e, s, x));
            if (normal.some((x)=>x === null || admission_open_argument(e, s, x))) return args(e, s, admission_projection(admission_body(e, k)), tld.T, xs, false);
        }
    }
    const ps = [];
    let U = T;
    xs.forEach((x, j)=>{
        const F = U === null ? U : B.term_wnf(e.book, U);
        if (F?.$ !== "All") {
            return oos("an application past its head's known type");
        }
        const v = j < nx ? spec_val(e, s, x) : null;
        ps.push([
            quant(F.q),
            x,
            F.A,
            v
        ]);
        U = F.B(v ?? x);
    });
    if (nx > 0 && ps.length >= nx) {
        const prefix = ps.slice(0, nx).map((p)=>p[3]);
        const name = B.admission_instance(e.book, k, prefix);
        const concrete = name === undefined ? undefined : e.book.tlds[name];
        if (concrete?.$ === "Def" && concrete.x === 0) return args(e, s, name, concrete.T, xs.slice(nx), live);
        throw new AdmissionInstanceRequest(k, prefix);
    }
    let n;
    try {
        const g = typeof k === "string" ? group_of(e, k) : null;
        if (g !== null) {
            return group_call(e, s, g, k, ps, U, live);
        }
        n = typeof k === "string" ? item_ref(e, k, ps.map((p)=>p[3]), live) : null;
    } catch (x) {
        if (x instanceof Reroute) {
            return args(e, s, k, T, xs, live);
        }
        throw x;
    }
    const a = {
        ...s,
        sub: live && n === s.self
    };
    return ps.filter((p)=>p[3] === null).reduce((f, [q, x, A])=>({
            $: "App",
            q,
            f,
            x: arg_term(e, a, x, A, live && q > 0)
        }), n === null ? k : {
        $: "Ref",
        k: n
    });
}
function group_of(e, k) {
    return e.groups.get(k) ?? null;
}
function regroup(e, key) {
    const ns = e.stack.slice(e.stack.indexOf(key)).map((x)=>x.split("\n")[0]);
    const gs = [
        ...new Set(ns.filter((x)=>x[0] === "\t").map((x)=>group_of(e, x.slice(1))))
    ];
    const ms = [
        ...new Set(ns.flatMap((x)=>x[0] === "\t" ? group_of(e, x.slice(1)).ms : [
                x
            ]))
    ];
    if (ms.length < 2 || gs.length === 1 && ms.length === gs[0].ms.length) {
        oos("a recursion through " + B.name_key(ms[0]) + " at other specialized arguments");
    }
    const at = (x)=>e.book.order.lastIndexOf(x);
    const k = ms.reduce((a, b)=>at(b) > at(a) ? b : a);
    const g = group_new(e, k, ms.filter((x)=>x !== k).sort((a, b)=>at(a) - at(b))) ?? oos("a mutual recursion through " + ms.map(B.name_key).join(", ") + " that no live parameter of " + B.name_key(k) + " leads");
    for (const x of g.ms){
        e.groups.set(x, g);
    }
    e.grew ||= gs.length > 0;
    throw new Regroup(key);
}
function group_new(e, k, hs) {
    const lead = Math.min(...hs.map((h)=>{
        const t = e.book.tlds[h].e;
        let n = 0;
        for(let x = t; x.$ === "Ann" || x.$ === "Lam"; x = x.$ === "Ann" ? x.x : x.f){
            n += x.$ === "Lam" ? 1 : 0;
        }
        const cs = back(t, k);
        const at = (x, j)=>x?.$ === "Ann" ? at(x.x, j) : x?.$ === "Var" && x.i === j;
        let j = 0;
        while(j < n && cs.length > 0 && cs.every((xs)=>at(xs[j], j))){
            j++;
        }
        return j;
    }));
    const tld = e.book.tlds[k];
    const doms = B.tele_unbind(e.book, tld.T).doms.slice(0, lead);
    if (hs.length === 0 || !doms.some(([q], j)=>q.$ !== "None" && (tld.$ !== "Def" || j >= tld.x))) {
        return null;
    }
    return {
        k,
        ms: [
            k,
            ...hs
        ],
        qs: doms.map(([q])=>quant(q))
    };
}
function back(t, k) {
    if (typeof t !== "object" || t === null) {
        return [];
    }
    let [f, xs] = [
        t,
        []
    ];
    while(f.$ === "App" || f.$ === "Ann"){
        [f, xs] = f.$ === "App" ? [
            f.f,
            [
                f.x,
                ...xs
            ]
        ] : [
            f.x,
            xs
        ];
    }
    return f.$ === "Ref" && f.k === k && xs.length > 0 ? [
        xs
    ] : Object.entries(t).flatMap(([j, v])=>j === "s" ? [] : back(v, k));
}
function trail(e) {
    return [
        e.out.length,
        e.todo.length,
        e.log.length
    ];
}
function undo(e, m) {
    e.out.length = m[0];
    e.todo.length = m[1];
    for (const [x, k] of e.log.splice(m[2])){
        x.delete(k);
    }
}
function put(e, x, k, v = "") {
    if (!x.has(k)) {
        e.log.push([
            x,
            k
        ]);
    }
    if (x instanceof Map) {
        x.set(k, v);
    } else {
        x.add(k);
    }
}
function group_call(e, s, g, m, ps, R, live) {
    const n = g.qs.length;
    if (ps.length < Math.max(e.book.tlds[m].n, n) || ps.slice(n).some((p)=>p[3] !== null)) {
        oos("a partial or specialized call to " + m + ", mutually recursive");
    }
    const k = item_ref(e, "\t" + g.k, ps.slice(0, n).map((p)=>p[3]), live);
    const a = {
        ...s,
        sub: live && k === s.self
    };
    const args = (xs, qs)=>xs.flatMap(([q, x, A, v], j)=>v !== null ? [] : [
                [
                    qs[j] ?? q,
                    arg_term(e, a, x, A, live && (qs[j] ?? q) > 0)
                ]
            ]);
    const sel = {
        $: "Tup",
        q: 1,
        a: {
            $: "Lab",
            k: name_tt(g.k)
        },
        b: UV
    };
    const x = [
        ...args(ps.slice(0, n), g.qs),
        [
            1,
            m === g.k ? sel : {
                $: "Tup",
                q: 1,
                a: {
                    $: "Lab",
                    k: name_tt(m)
                },
                b: {
                    $: "Tup",
                    q: 1,
                    a: sel,
                    b: UV
                }
            }
        ],
        ...args(ps.slice(n), [])
    ].reduce((f, [q, x])=>({
            $: "App",
            q,
            f,
            x
        }), {
        $: "Ref",
        k
    });
    return {
        $: "Ann",
        x,
        T: term(e, s, R, false)
    };
}
function group_emit(e, g, cols, n) {
    const { s, ps: ls, xs: lead } = tele_open(e, {
        ...scope_nil(),
        self: n
    }, e.book.tlds[g.k].T, cols, g.qs.length);
    const rest = (s1, m)=>{
        const tld = e.book.tlds[m];
        const nx = tld.$ === "Def" ? tld.x : 0;
        const r = tele_open(e, s1, tld.T, lead, Math.max(tld.n, lead.length));
        const qs = B.tele_unbind(e.book, tld.T).doms.map(([q])=>quant(q));
        return {
            ...r,
            vs: r.xs.flatMap((x, j)=>j < nx ? [] : [
                    [
                        qs[j],
                        term(e, r.s, x, false)
                    ]
                ]),
            cs: r.xs.map((x, j)=>j < nx ? x : null)
        };
    };
    const tags = g.ms.map(name_tt);
    const sel = (f)=>({
            $: "Prj",
            h: mats(tags, (i)=>i === 0 ? unit(f(g.ms[i])) : {
                    $: "Prj",
                    h: {
                        $: "Prj",
                        h: mats([
                            name_tt(g.k)
                        ], ()=>unit(unit(f(g.ms[i]))))
                    }
                })
        });
    const l0 = s.D;
    const s0 = scope_kq(scope_hide(s), l0, 1);
    const mode = sel((m)=>{
        const r = rest(s0, m);
        return alls(r.ps, term(e, r.s, r.T, false));
    });
    const Sel = {
        $: "Sig",
        q: 1,
        l: l0,
        A: {
            $: "Enu",
            ks: tags
        },
        B: {
            $: "App",
            q: 1,
            x: {
                $: "Var",
                l: l0
            },
            f: mats(tags, (i)=>i === 0 ? UT : {
                    $: "Sig",
                    q: 1,
                    l: l0 + 1,
                    A: {
                        $: "Sig",
                        q: 1,
                        l: l0 + 1,
                        A: {
                            $: "Enu",
                            ks: [
                                name_tt(g.k)
                            ]
                        },
                        B: UT
                    },
                    B: UT
                })
        }
    };
    const To = alls(ls, {
        $: "All",
        q: 1,
        l: l0,
        A: Sel,
        B: {
            $: "App",
            q: 1,
            f: mode,
            x: {
                $: "Var",
                l: l0
            }
        }
    });
    const ks = ls.filter(([q])=>q === 1).map(([, l])=>l);
    const body = sel((m)=>convoy_bind(e, s0, ks, (s2)=>{
            const r = rest(s2, m);
            return lams(e, r.ps, arm(e, r.s, m, r.cs, r.vs));
        }, []));
    const v = ks.reduce((f, l)=>({
            $: "App",
            q: 1,
            f,
            x: {
                $: "Var",
                l
            }
        }), {
        $: "App",
        q: 1,
        f: body,
        x: {
            $: "Var",
            l: l0
        }
    });
    e.out.push([
        n,
        To,
        lams(e, [
            ...ls,
            [
                1,
                l0
            ]
        ], v),
        false
    ]);
}
function arm(e, s, k, cols, vs) {
    const tld = e.book.tlds[k];
    const ps = tld.x === 0 ? null : new Map(B.tele_unbind(e.book, tld.T).doms.slice(0, tld.x).map(([, p], j)=>[
            k + "~" + p,
            cols[j]
        ]));
    const t0 = B.term_higher(tld.e);
    let t = ps === null ? B.term_higher(B.term_lower(t0)) : subst(t0, 0, (o)=>o.$ === "Ref" ? ps.get(o.k) ?? undefined : undefined);
    let si = {
        ...s,
        c: [],
        d: 0,
        cols: cols.slice(tld.x),
        sub: false
    };
    let j = 0;
    for(let [x, T] = open(t); x.$ === "Lam" && T !== null; [x, T] = open(t)){
        const F = B.term_wnf(e.book, T);
        const v = si.cols[0] ?? null;
        if (F.$ !== "All" || v === null && j === vs.length) {
            break;
        }
        si = {
            ...si,
            cols: si.cols.slice(1)
        };
        si = v !== null ? scope_bind(si, {
            $: "Efq"
        }, F.A, false, v) : scope_bind(si, vs[j++][1], F.A, false);
        t = x.f(B.Var(x.k, si.d - 1));
    }
    return vs.slice(j).reduce((f, [q, x])=>({
            $: "App",
            q,
            f,
            x
        }), tree(e, si, t, []));
}
function arg_term(e, s, x, A, live) {
    const [y, T] = open(x);
    const tree = y.$ === "Lam" || y.$ === "Mat" || y.$ === "Efq";
    const all = tree || y.$ === "Ctr" ? null : all_of(e, A);
    if (all !== null && (!(live && s.sub) || T !== null && !qsig_eq(e, T, A, s.d))) {
        return term(e, s, eta(x, all), live);
    }
    return term(e, s, T === null && (tree || y.$ === "Ctr") ? B.Ann(x, A) : x, live);
}
function qsig_eq(e, T, A, d) {
    const F = B.term_wnf(e.book, T);
    const G = B.term_wnf(e.book, A);
    if (F.$ !== "All" || G.$ !== "All") {
        return F.$ !== "All" && G.$ !== "All";
    }
    const x = B.Var(G.k, d);
    return F.q.$ === G.q.$ && qsig_eq(e, F.B(x), G.B(x), d + 1);
}
function ctr_term(e, s, x, T, live) {
    const ctr = e.book.ctrs[x.k];
    if (ctr === undefined) {
        oos("an unknown constructor " + B.name_key(x.k));
    }
    const f = B.book_fam(e.book, x.k);
    const fam = e.book.tlds[f];
    const w = B.u32_from_term(x) ?? B.u32_from_term(x, "F32");
    if (!s.sub && w !== null) {
        if (fam.n !== 0) {
            oos("a word literal of a parameterized datatype");
        }
        return word_ref(e, x.k, f, w);
    }
    const G = T === null || fam.n === 0 ? null : B.term_wnf(e.book, T);
    const ps = G?.$ === "ADT" ? G.x : Array.from({
        length: fam.n
    }, ()=>B.Var("_", -1));
    let F = B.tele_fill(e.book, ctr.T, ps, B.ctx_nil());
    const fs = [];
    for (const a of x.x){
        const A = B.term_wnf(e.book, F);
        if (A.$ !== "All") {
            oos("a constructor past its fields");
        }
        const q = quant(A.q);
        fs.push([
            q,
            arg_term(e, s, a, A.A, live && q > 0)
        ]);
        F = A.B(a);
    }
    const k = name_tt(x.k);
    const tail = fs.reduceRight((b, [q, a])=>({
            $: "Tup",
            q,
            a,
            b
        }), UV);
    return {
        $: "Tup",
        q: 1,
        a: {
            $: "Lab",
            k
        },
        b: tail
    };
}
function word_ref(e, T, fam, n) {
    const key = "\tword " + T + " " + String(n);
    let k = e.names.get(key);
    if (k === undefined) {
        k = fresh(e, T + ".lit" + String(n));
        put(e, e.names, key, k);
        const v = term(e, {
            ...scope_nil(),
            sub: true
        }, B.Ctr(T, [
            B.word_to_term(n)
        ]), true);
        e.out.push([
            k,
            {
                $: "Ref",
                k: item_ref(e, fam, [], false)
            },
            v,
            false
        ]);
    }
    return {
        $: "Ref",
        k
    };
}
function let_term(e, s, x, live, put = new Set()) {
    let s2 = s;
    const ls = [];
    for(let j = 0; j < x.k.length; j++){
        const q = quant(x.q[j]);
        const V = open(x.v[j])[1];
        if (put.has(j)) {
            s2 = scope_bind(s2, {
                $: "Efq"
            }, V, false, x.v[j]);
            continue;
        }
        const at = {
            ...s,
            D: s2.D,
            kq: s2.kq
        };
        const v = term(e, at, x.v[j], live && q > 0);
        if (v.$ === "Var") {
            s2 = scope_bind(s2, v, V, false);
        } else {
            const l = s2.D;
            const w = inferable(v) ? v : V === null ? oos("a let with no known type") : {
                $: "Ann",
                x: v,
                T: term(e, at, V, false)
            };
            ls.push([
                q,
                l,
                w,
                j
            ]);
            s2 = scope_kq(scope_bind(s2, {
                $: "Var",
                l
            }, V, true), l, q);
        }
    }
    const xs = x.k.map((k, j)=>B.Var(k, s.d + j));
    const f = term(e, s2, x.f(xs), live);
    const more = ls.filter(([, l, v])=>live && v.$ !== "App" && v.$ !== "Ref" && self_arg(f, s.self, l)).map(([, , , j])=>j);
    if (more.length > 0) {
        return let_term(e, s, x, live, new Set([
            ...put,
            ...more
        ]));
    }
    return ls.reduceRight((b, [q, l, v])=>({
            $: "Let",
            q: !e.admissionStage && q === 1 && uses(e, b, l) > 1 ? 2 : q,
            l,
            v,
            f: b
        }), f);
}
function rwt_term(e, s, x, live) {
    const E0 = open(x.e)[1];
    const e0 = term(e, s, x.e, live);
    const ev = inferable(e0) || E0 === null ? e0 : {
        $: "Ann",
        x: e0,
        T: term(e, s, E0, false)
    };
    const [p] = open(x.p);
    if (p.$ !== "Lam") {
        oos("a rewrite motive that is not a λ");
    }
    const l = s.D;
    const Q = E0 === null ? null : B.term_wnf(e.book, E0);
    const q = Q !== null && Q.$ === "Eql" ? Q : null;
    const s2 = scope_bind(s, {
        $: "Var",
        l
    }, q && q.T, true);
    const [p2] = open(p.f(B.Var(p.k, s.d)));
    if (p2.$ !== "Lam") {
        oos("a rewrite motive that is not a λ over its evidence");
    }
    const s3 = scope_bind(s2, {
        $: "Var",
        l: l + 1
    }, q && B.Eql(q.a, B.Var(p.k, s.d), q.T), true);
    const P = term(e, s3, p2.f(B.Var(p2.k, s2.d)), false);
    return {
        $: "Rwt",
        e: ev,
        l,
        P,
        f: term(e, s, x.f, live)
    };
}
function self_arg(o, k, l) {
    let h = o;
    let found = false;
    while(h.$ === "App"){
        found ||= h.x.$ === "Var" && h.x.l === l && h.q > 0;
        h = h.f;
    }
    return found && h.$ === "Ref" && h.k === k || Object.values(o).some((v)=>is_o(v) && self_arg(v, k, l));
}
function o_refs(o, out = new Set()) {
    if (o.$ === "Ref") {
        out.add(o.k);
    }
    for (const v of Object.values(o)){
        if (is_o(v)) {
            o_refs(v, out);
        }
    }
    return out;
}
function is_o(v) {
    return typeof v === "object" && v !== null && "$" in v;
}
function alls(ps, b, $ = "All") {
    return ps.reduceRight((B, [q, l, A])=>({
            $,
            q,
            l,
            A,
            B
        }), b);
}
function mats(ks, h) {
    return ks.reduceRight((m, k, i)=>({
            $: "Mat",
            k,
            h: h(i),
            m
        }), {
        $: "Efq"
    });
}
function unit(h) {
    return mats([
        "()"
    ], ()=>h);
}
function lams(e, ps, b) {
    return ps.reduceRight((f, [q, l])=>({
            $: "Lam",
            q: q === 1 && uses(e, f, l) > 1 ? 2 : q,
            l,
            f
        }), b);
}
function inferable(o) {
    return o.$ === "App" ? inferable(o.f) : [
        "Var",
        "Ref",
        "Ann",
        "Typ",
        "Min",
        "All",
        "Enu",
        "Eql"
    ].includes(o.$);
}
function uses(e, o, l) {
    return o_uses(e, o).get(l) ?? 0;
}
function o_uses(e, o, live = true, out) {
    const kept = e.uses.get(o);
    if (out === undefined && kept === undefined) {
        e.uses.set(o, o_uses(e, o, true, new Map()));
    }
    if (out === undefined) {
        return e.uses.get(o);
    }
    if (kept !== undefined) {
        kept.forEach((n, l)=>out.set(l, (out.get(l) ?? 0) + (live ? n : 0)));
        return out;
    }
    switch(o.$){
        case "Var":
            return out.set(o.l, (out.get(o.l) ?? 0) + (live ? 1 : 0));
        case "Ann":
            return o_uses(e, o.T, false, o_uses(e, o.x, live, out));
        case "Let":
            return o_uses(e, o.f, live, o_uses(e, o.v, live && o.q > 0, out));
        case "All":
        case "Sig":
            return o_uses(e, o.B, false, o_uses(e, o.A, false, out));
        case "Lam":
            return o_uses(e, o.f, live, out);
        case "App":
            return o_uses(e, o.x, live && o.q > 0, o_uses(e, o.f, live, out));
        case "Tup":
            return o_uses(e, o.b, live, o_uses(e, o.a, live && o.q > 0, out));
        case "Prj":
            return o_uses(e, o.h, live, out);
        case "Mat":
            return o_uses(e, o.m, live, o_uses(e, o.h, live, out));
        case "Min":
            return o_uses(e, o.b, live, o_uses(e, o.a, live, out));
        case "Eql":
            return o_uses(e, o.T, false, o_uses(e, o.b, false, o_uses(e, o.a, false, out)));
        case "Rwt":
            return o_uses(e, o.f, live, o_uses(e, o.P, false, o_uses(e, o.e, live, out)));
        default:
            return out;
    }
}
function book_show(e) {
    let p = "x";
    while([
        ...e.taken
    ].some((k)=>new RegExp("^" + p + "[0-9]+$").test(k))){
        p += "x";
    }
    return e.out.map(([k, T, v, m])=>(m ? "opaque " : "") + k + " : " + o_show(T, p) + " =\n  " + o_show(v, p)).join("\n\n") + "\n";
}
function mark(q) {
    return q === 0 ? "-" : q === 2 ? "+" : "";
}
function o_show(o, p) {
    const nm = (l)=>p + String(l);
    switch(o.$){
        case "Var":
            return nm(o.l);
        case "Ref":
            return o.k;
        case "Ann":
            return "{" + o_show(o.x, p) + " : " + o_show(o.T, p) + "}";
        case "Let":
            return "!" + mark(o.q) + nm(o.l) + " = " + o_show(o.v, p) + "; " + o_show(o.f, p);
        case "Typ":
            return "*(" + o_show(o.q, p) + ")";
        case "Min":
            return "(" + o_show(o.a, p) + " <&> " + o_show(o.b, p) + ")";
        case "All":
            return "∀" + mark(o.q) + nm(o.l) + " : " + o_show(o.A, p) + " -> " + o_show(o.B, p);
        case "Lam":
            return "λ" + mark(o.q) + nm(o.l) + " => " + o_show(o.f, p);
        case "App":
            {
                const xs = [];
                let f = o;
                while(f.$ === "App"){
                    xs.push(mark(f.q) + o_show(f.x, p));
                    f = f.f;
                }
                return "(" + o_show(f, p) + " " + xs.reverse().join(" ") + ")";
            }
        case "Sig":
            return "Σ" + mark(o.q) + nm(o.l) + " : " + o_show(o.A, p) + " -> " + o_show(o.B, p);
        case "Tup":
            return "(" + mark(o.q) + o_show(o.a, p) + ", " + o_show(o.b, p) + ")";
        case "Prj":
            return "λ{(,): " + o_show(o.h, p) + "}";
        case "Enu":
            return "<" + o.ks.join(", ") + ">";
        case "Lab":
            return o.k === "()" ? "()" : "." + o.k;
        case "Mat":
            return "λ{" + o_show({
                $: "Lab",
                k: o.k
            }, p) + ": " + o_show(o.h, p) + "; " + o_show(o.m, p) + "}";
        case "Efq":
            return "λ{}";
        case "Eql":
            return "{" + o_show(o.a, p) + " == " + o_show(o.b, p) + " : " + o_show(o.T, p) + "}";
        case "Rfl":
            return "{==}";
        case "Rwt":
            return "%" + o_show(o.e, p) + " : " + nm(o.l) + ", " + nm(o.l + 1) + " => " + o_show(o.P, p) + "; " + o_show(o.f, p);
    }
}
function kernel_bin() {
    const env = process.env.BENDTT;
    if (env !== undefined && env !== "") {
        return env;
    }
    const src = path.join(B.BEND_DIR, "bendtt.lean");
    const text = fs.readFileSync(src, "utf8");
    const hash = crypto.createHash("sha256").update(LEAN_VERSION).update("\0").update(text).digest("hex").slice(0, 16);
    const dir = path.join(os.homedir(), ".bend", "bendtt", hash);
    const bin = path.join(dir, "bendtt");
    if (fs.existsSync(bin)) {
        return bin;
    }
    const home = path.join(os.homedir(), ".elan", "toolchains", "leanprover--lean4---v" + LEAN_VERSION, "bin");
    const tool = (t)=>fs.existsSync(path.join(home, t)) ? path.join(home, t) : t;
    fs.mkdirSync(dir, {
        recursive: true
    });
    const fail = (why)=>{
        throw new Error("BendTT infrastructure: the kernel did not build (" + why + "); --verdict needs Lean v" + LEAN_VERSION + " (elan toolchain leanprover/lean4:v" + LEAN_VERSION + "), or $BENDTT set to a built kernel");
    };
    const run = (bin, args)=>{
        const [got, text] = run_read(bin, args, {
            cwd: dir
        });
        if (got.status !== 0) {
            fail(bin + ": " + (got.error?.message ?? text.slice(0, 300)));
        }
        return text;
    };
    const version = run(tool("lean"), [
        "--version"
    ]);
    if (version.match(/^Lean \(version ([^,\s)]+)/m)?.[1] !== LEAN_VERSION) {
        fail("lean --version: " + version.trim().slice(0, 300));
    }
    fs.copyFileSync(src, path.join(dir, "bendtt.lean"));
    run(tool("lean"), [
        "-c",
        "bendtt.c",
        "bendtt.lean"
    ]);
    run(tool("leanc"), [
        "-O3",
        "-DNDEBUG",
        "bendtt.c",
        "-o",
        "bendtt"
    ]);
    return bin;
}
export function run_read(bin, args, opts = {}) {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "bend-run-"));
    const log = path.join(dir, "out");
    const fd = fs.openSync(log, "w");
    try {
        const got = child.spawnSync(bin, args, {
            ...opts,
            stdio: [
                "ignore",
                fd,
                fd
            ]
        });
        return [
            got,
            fs.readFileSync(log, "utf8")
        ];
    } finally{
        fs.closeSync(fd);
        fs.rmSync(dir, {
            recursive: true,
            force: true
        });
    }
}
function kernel_check(text) {
    const env = {
        ...process.env,
        LEAN_STACK_SIZE_KB: "4194304"
    };
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "bendtt-"));
    try {
        const inp = path.join(dir, "in.bendtt");
        fs.writeFileSync(inp, text, {
            flag: "wx"
        });
        const [got, out] = run_read(kernel_bin(), [
            inp
        ], {
            env
        });
        if (got.error || got.signal || got.status === null || out.trim() !== "ALL PROOFS CHECK" && !out.startsWith("SOME PROOFS FAIL")) {
            throw new Error("BendTT infrastructure: " + (got.error?.message ?? (got.signal ? "kernel terminated by " + got.signal : out.trim() || "kernel exited " + got.status + " without a verdict")));
        }
        const why = out.trim().split("\n").slice(1).join("\n");
        return got.status === 0 && out.trim() === "ALL PROOFS CHECK" ? null : why || "kernel exited " + got.status + " after " + out.trim();
    } finally{
        fs.rmSync(dir, {
            recursive: true,
            force: true
        });
    }
}
export function safe_emit(book, out) {
    const got = safe_book(book);
    fs.writeFileSync(out, got.text);
    return got.oos.map(([k, why])=>"- " + B.name_key(k) + ": " + why + "\n");
}
export function safe_check(book) {
    const got = safe_book(book);
    return got.oos.length === 0 ? kernel_check(got.text) : "BendTT: out of scope:\n" + got.oos.map(([k, why])=>"- " + B.name_key(k) + ": " + why).join("\n");
}
import { prepareClosedInstances, resolvePhysicalInstance, instanceSourceClaims, instanceClosureFingerprint } from "jaydb:admission-closure";
function admission_open_argument(e, s, value) {
    const locals = e.admissionStage?.locals;
    const visit = (node)=>{
        if (node === null || typeof node !== "object") return false;
        if (node.$ === "Var" && node.i >= 0 && node.i < s.d) return true;
        if (node.$ === "Ref" && locals?.has(node.k)) return true;
        return Object.entries(node).some(([key, child])=>key !== "s" && visit(child));
    };
    return visit(B.term_lower(value, s.d));
}
export function admission_prepare_book(book, options = {}) {
    try {
        const initial = new Set(Object.keys(book.tlds));
        let rewrites = 0;
        let fuel = 1n << 22n;
        for(;;){
            const prepared = prepareClosedInstances(B, book, options);
            rewrites += prepared.rewrites;
            const previous = [
                MODEL_FUEL,
                ADMISSION_DEADLINE,
                ADMISSION_SCHEMAS,
                ADMISSION_INSTANCES,
                ADMISSION_SOURCE_CLAIMS
            ];
            MODEL_FUEL = fuel;
            ADMISSION_DEADLINE = options.deadlineNs === undefined ? null : BigInt(options.deadlineNs);
            ADMISSION_SCHEMAS = [];
            ADMISSION_INSTANCES = [];
            ADMISSION_SOURCE_CLAIMS = instanceSourceClaims(book);
            try {
                admission_deadline();
                const before = instanceClosureFingerprint(B, book);
                safe_book(admission_snapshot(book));
                admission_deadline();
                if (instanceClosureFingerprint(B, book) !== before) continue;
                return {
                    ...prepared,
                    rewrites,
                    created: Object.keys(book.tlds).filter((k)=>!initial.has(k))
                };
            } catch (error) {
                if (error instanceof AdmissionInstanceRequest) {
                    resolvePhysicalInstance(B, book, error.name, error.parameters);
                    continue;
                }
                if (error instanceof SafeResourceExhausted) {
                    fuel *= 2n;
                    continue;
                }
                throw error;
            } finally{
                [MODEL_FUEL, ADMISSION_DEADLINE, ADMISSION_SCHEMAS, ADMISSION_INSTANCES, ADMISSION_SOURCE_CLAIMS] = previous;
            }
        }
    } catch (error) {
        if (error?.code === "HOST_VERIFICATION_DEADLINE") throw new SafeDeadlineExceeded(error.message);
        throw error;
    }
}
function admission_snapshot(book) {
    return {
        ...book,
        tlds: {
            ...book.tlds
        },
        tmps: Object.fromEntries(Object.entries(book.tmps).map(([k, v])=>[
                k,
                new Map(v)
            ]))
    };
}
function admission_source_links(e) {
    for (const [k, expected] of ADMISSION_SOURCE_CLAIMS){
        admission_deadline();
        const T = e.book.tlds[k].T;
        const s = scope_nil();
        const equality = {
            $: "Eql",
            T: term(e, s, T, false),
            a: arg_term(e, s, B.term_higher(e.book.tlds[k].e), T, false),
            b: arg_term(e, s, B.term_higher(expected), T, false)
        };
        const payload = {
            $: "Ann",
            x: {
                $: "Rfl"
            },
            T: equality
        };
        e.out.push([
            fresh(e, name_tt(k) + ".source_link"),
            UT,
            {
                $: "Let",
                q: 0,
                l: 0,
                v: payload,
                f: UV
            },
            false
        ]);
    }
}
function admission_roots(e) {
    const roots = [
        ...new Set([
            ...e.book.order
        ].reverse())
    ].reverse().filter((k)=>e.book.tlds[k].b !== true);
    for (const [name, def] of Object.entries(e.book.tlds)){
        if (def.b !== true && !roots.includes(name)) {
            roots.push(name);
            ADMISSION_INSTANCES.push(name);
        }
    }
    return roots;
}
function admission_bundle_type(T) {
    return {
        $: "Sig",
        q: 0,
        l: 0,
        A: T,
        B: UT
    };
}
function admission_projection(body) {
    const T = body.T ?? oos("a cyclic template type without a checked header");
    const projection = {
        $: "Ann",
        x: {
            $: "Prj",
            h: {
                $: "Lam",
                q: 0,
                l: 0,
                f: {
                    $: "Lam",
                    q: 1,
                    l: 1,
                    f: {
                        $: "Var",
                        l: 0
                    }
                }
            }
        },
        T: {
            $: "All",
            q: 1,
            l: 0,
            A: admission_bundle_type(T),
            B: T
        }
    };
    return {
        $: "App",
        q: 1,
        f: projection,
        x: {
            $: "Ref",
            k: body.name
        }
    };
}
function admission_body(e, k) {
    const bodies = e.admissionBodies ??= new Map();
    const prior = bodies.get(k);
    if (prior !== undefined) return prior;
    admission_deadline();
    const tld = e.book.tlds[k];
    if (tld.e === undefined) oos("a template without its primary checked tree");
    const item = {
        name: fresh(e, name_tt(k) + ".template_body")
    };
    put(e, bodies, k, item);
    const book = {
        ...e.book,
        tlds: Object.assign(Object.create(null), e.book.tlds)
    };
    const se = {
        ...e,
        book,
        mb: {
            ...book,
            tlds: Object.create(book.tlds)
        }
    };
    const stage = {
        refs: new Map(),
        locals: new Set(),
        header: (name)=>{
            const def = e.book.tlds[name];
            return def?.$ === "Def" && def.x > 0 ? {
                o: admission_projection(admission_body(e, name)),
                T: def.T
            } : undefined;
        }
    };
    se.admissionStage = stage;
    item.T = term(se, scope_nil(), tld.T, false);
    let s = scope_nil(), T = tld.T;
    const binders = [];
    for(let j = 0; j < tld.x; j++){
        admission_deadline();
        const F = B.term_wnf(book, T);
        if (F.$ !== "All") oos("template prefix exceeds its telescope");
        const name = k + "~" + F.k;
        const domain = B.term_snf(book, F.A);
        const A = term(se, s, domain, false);
        const o = {
            $: "Var",
            l: s.D
        };
        binders.push([
            quant(F.q),
            s.D,
            A
        ]);
        stage.refs.set(name, {
            o,
            T: domain
        });
        stage.locals.add(name);
        book.tlds[name] = {
            $: "Def",
            n: 0,
            x: 0,
            T: F.A,
            v: null,
            b: true
        };
        s = scope_hide(s);
        T = F.B(B.Ref(name));
    }
    item.body = lams(se, binders, tree(se, s, B.term_higher(tld.e), []));
    e.out.push([
        item.name,
        admission_bundle_type(item.T),
        {
            $: "Tup",
            q: 0,
            a: item.body,
            b: UV
        },
        false
    ]);
    return item;
}
function admission_schema(e, k) {
    const item = admission_body(e, k);
    const n = fresh(e, name_tt(k) + ".compile_schema");
    const payload = {
        $: "Ann",
        x: item.body,
        T: item.T
    };
    e.out.push([
        n,
        UT,
        {
            $: "Let",
            q: 0,
            l: 0,
            v: payload,
            f: UV
        },
        false
    ]);
    ADMISSION_SCHEMAS.push(k);
    return [
        [
            n
        ],
        null
    ];
}
export function admission_safe_emit(book, out, options = {}) {
    admission_prepare_book(book, options);
    const previous = [
        MODEL_FUEL,
        ADMISSION_DEADLINE,
        ADMISSION_SCHEMAS,
        ADMISSION_INSTANCES,
        ADMISSION_SOURCE_CLAIMS
    ];
    MODEL_FUEL = BigInt(options.modelFuel ?? "4194304");
    ADMISSION_DEADLINE = options.deadlineNs === undefined ? null : BigInt(options.deadlineNs);
    ADMISSION_SCHEMAS = [];
    ADMISSION_INSTANCES = [];
    ADMISSION_SOURCE_CLAIMS = instanceSourceClaims(book);
    try {
        let attempts = 0n;
        for(;;){
            admission_deadline();
            attempts++;
            ADMISSION_SCHEMAS = [];
            ADMISSION_INSTANCES = [];
            try {
                const oos = safe_emit(admission_snapshot(book), out);
                admission_deadline();
                return {
                    oos,
                    schemas: [
                        ...new Set(ADMISSION_SCHEMAS)
                    ],
                    instances: [
                        ...new Set(ADMISSION_INSTANCES)
                    ],
                    modelFuel: MODEL_FUEL.toString(),
                    modelAttempts: attempts.toString()
                };
            } catch (error) {
                if (!(error instanceof SafeResourceExhausted)) throw error;
                MODEL_FUEL *= 2n;
            }
        }
    } finally{
        [MODEL_FUEL, ADMISSION_DEADLINE, ADMISSION_SCHEMAS, ADMISSION_INSTANCES, ADMISSION_SOURCE_CLAIMS] = previous;
    }
}
