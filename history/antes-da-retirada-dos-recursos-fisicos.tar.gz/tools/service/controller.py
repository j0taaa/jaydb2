"""Serial controller. Database semantics execute in checked Bend CPU modules.

This integration is under development; see native/README.md for the remaining
backend and whole-executable proof obligations.
"""
from __future__ import annotations
from dataclasses import dataclass
import json
import os
from pathlib import Path
import select
import selectors
import shutil
import sys
import tempfile
import time

from .abi import Module, NativeFailure, NativeOwnershipPending
from .loading import Runtime as LoadingRuntime, LibraryScope
from .lifecycle import LifecycleRuntime, ProcessOwner
from .isolated import command as isolated_python
from .staging import Environment, ROOT
from .naturals import decimal, parse_decimal
from .entry import prepare_entry
from .frames import error_frame
from .memory import MemoryExcess

# Before a configuration has been checked there is no public budget to read.
# These cover the declared Linux x86_64 domains, rather than a second startup
# quota: a nonnegative signed-64-bit time_t is below CLOCK_END_NS; the sum of
# user capacities across positive signed-32-bit PIDs/fds with 64-bit extents is
# strictly below 2**128. No corresponding storage is reserved or allocated.
CLOCK_END_NS = (1 << 63) * 1_000_000_000
ALLOCATION_DOMAIN_BYTES = 1 << 128


class StageTimeout(RuntimeError):
    pass


class IncompleteIntegration(Exception):
    """A selected host path is not connected; never an invented FalhaReal."""


StageMemory = MemoryExcess


class CompileFailure(RuntimeError):
    def __init__(self, detail):
        self.detail = detail
        super().__init__(str(detail))


@dataclass(frozen=True)
class RequestProposal:
    response: bytes
    state: bytes | None
    deadline_ns: int


def remaining(deadline):
    left = deadline - time.monotonic_ns()
    if left <= 0:
        raise StageTimeout('Prazo da etapa atingido')
    return left


def wait_seconds(deadline, maximum_ns):
    # Configuration times are Nat, not IEEE doubles or uint64. Reduce the
    # individual OS wait before conversion; the absolute integer deadline is
    # unchanged, including when it is larger than the host's float range.
    return min(remaining(deadline), maximum_ns) / 1_000_000_000


def remaining_seconds_text(deadline):
    whole, fraction = divmod(remaining(deadline), 1_000_000_000)
    return decimal(whole, lambda: remaining(deadline)) + f'.{fraction:09d}'


def packet(first, second):
    return len(first).to_bytes(8, 'big') + first + second


def split(data):
    if len(data) < 8:
        raise RuntimeError('Transporte interno truncado')
    n = int.from_bytes(data[:8], 'big')
    if n > len(data) - 8:
        raise RuntimeError('Comprimento interno inválido')
    return data[8:8+n], data[8+n:]


def helper(command, deadline, memory, error_file=None, *, memory_window=None, lifecycle_runtime=None):
    runtime = LifecycleRuntime.current() if lifecycle_runtime is None else lifecycle_runtime
    if runtime.live_processes:
        raise IncompleteIntegration('An earlier helper still has unresolved ownership')
    if memory_window is not None and memory_window.ceiling!=memory:
        raise ValueError('Helper and allocation window must use the same public ceiling')
    # A process-group RSS sum is not the selected allocation measure. Until a
    # complete scenario window is supplied, this experimental controller has
    # no whole-service memory witness. Native local capacity refusals likewise
    # remain distinct from public memory limits.
    # The C owner records pipes and PID before returning to Python. WNOWAIT
    # pins the leader until killpg, including a failure inside start's return.
    p = None
    try:
        p = ProcessOwner.prepare(runtime, command)
        p.start()
        streams = (p.stdout, p.stderr)
        collected = {stream.fileno(): [] for stream in streams}
        with selectors.DefaultSelector() as ready:
            for stream in streams:
                os.set_blocking(stream.fileno(), False)
                ready.register(stream, selectors.EVENT_READ)
            exited = False
            while True:
                if memory_window is not None:
                    memory_window.poll()
                if not exited:
                    exited = p.poll()
                    if exited:
                        # The unreaped leader still owns this PID/group ID.
                        # No descendant may outlive the compilation stage,
                        # including after a nominally successful leader exit.
                        p.stop_and_wait()
                if exited and not ready.get_map():
                    break
                for event, _ in ready.select(wait_seconds(deadline, 10_000_000)):
                    fd = event.fd
                    try:
                        chunk = os.read(fd, 65536)
                    except BlockingIOError:
                        continue
                    if chunk:
                        collected[fd].append(chunk)
                    else:
                        ready.unregister(event.fileobj)
            out, err = (b''.join(collected[stream.fileno()]) for stream in streams)
    finally:
        # prepare may itself be interrupted before assigning p. Its registered
        # owner still contains every acquired descriptor and any child PID.
        try:
            for owner in runtime.live_processes:
                owner.close()
            if runtime.live_processes:
                raise IncompleteIntegration('Helper ownership remains unresolved')
        except IncompleteIntegration:
            raise
        except BaseException as error:
            if runtime.live_processes:
                raise IncompleteIntegration('Helper cleanup remains unresolved') from error
            raise
    if memory_window is not None:
        memory_window.poll()
    if p.returncode:
        detail = None
        if error_file and error_file.exists():
            detail = json.loads(error_file.read_text())
        if detail is None:
            try:
                reported = json.loads(out)
                if 'error' in reported:
                    detail = {'code': 'NATIVE_BUILD_' + reported['error'], 'message': reported.get('message', '')}
            except (ValueError, TypeError):
                pass
        raise CompileFailure(detail or {'code': 'HELPER', 'message': err.decode('utf-8', 'replace')[-8000:]})
    remaining(deadline)
    return out


def build(environment, directory, purpose, toolchain, *, deadline, memory, metadata=None,
          tools_root=ROOT, memory_window=None,loading_runtime=None,lifecycle_runtime=None,
          library_scope=None):
    try:
        environment.stage(directory, purpose, metadata)
    except ValueError as e:
        # Header/dependency rejection is admission, not a reason to destroy an
        # otherwise usable instance after a well-framed request.
        raise CompileFailure({'code': 'DEPENDENCY', 'message': str(e)}) from e
    c = directory / 'checked.c'
    # Exact public Nat values travel through a private file, including the
    # original absolute verification deadline shared by every kernel retry.
    resources = directory / 'compiler-resources.json'
    resources.write_text(json.dumps({
        'deadline_ns': decimal(deadline, lambda: remaining(deadline)),
        'timeout_ns': decimal(remaining(deadline), lambda: remaining(deadline)),
        'compiler_memory_bytes': decimal(memory, lambda: remaining(deadline))}))
    helper(isolated_python(tools_root, 'admission', [
            '--resources-json', str(resources), '--', 'node',
            str(tools_root / 'tools/service/compile.mjs'), str(directory / 'manifest.json'), str(c),
            str(toolchain[0]), str(toolchain[1]), str(resources)]),
            deadline, memory, Path(str(c) + '.error.json'), memory_window=memory_window,
            lifecycle_runtime=lifecycle_runtime)
    report = json.loads(Path(str(c) + '.json').read_text())
    # Distinct absolute path per module: dlopen cannot return an earlier build.
    output = directory / (report['cSha256'] + '.so')
    source = c.read_text()
    ids = {}
    for name, symbol in [('input', 'read'), ('output', 'write'), ('enter', 'enter')]:
        macro = 'CID_Native_' + symbol
        ids[name] = macro if f'#define {macro} ' in source else 'none'
    args = [str(c), str(output), '--input-cid', ids['input'], '--output-cid', ids['output']]
    # Nat resource limits can exceed both Python's decimal conversion quota and
    # Linux's per-argument size. The helper receives a private file path instead.
    resources.write_text(json.dumps({
        'timeout_ns': decimal(remaining(deadline), lambda: remaining(deadline)),
        'compiler_memory_bytes': decimal(memory, lambda: remaining(deadline))}))
    args += ['--resources-json', str(resources)]
    if ids['enter'] != 'none':
        args += ['--enter-cid', ids['enter']]
    if purpose == 'execute':
        for key, symbol in [('loop', 'loop'), ('continue', 'Continuar'), ('prepare', 'Preparar'),
                            ('finish', 'Encerrar'), ('inconsistent', 'Inconsistente')]:
            args += [f'--{key}-cid', 'CID_Native_' + symbol]
    helper(isolated_python(tools_root, 'native', args), deadline, memory,
           memory_window=memory_window,lifecycle_runtime=lifecycle_runtime)
    limits = {k: parse_decimal(v, lambda: remaining(deadline)) for k, v in report['limits'].items()}
    remaining(deadline)
    module = Module(output,loading_runtime=loading_runtime,lifecycle_runtime=lifecycle_runtime,
                    library_scope=library_scope)
    try:
        remaining(deadline)
    except BaseException:
        module.close()
        raise
    return module, limits


def exact_read(fd, size, deadline):
    data = bytearray()
    while len(data) < size:
        ready, _, _ = select.select([fd], [], [], wait_seconds(deadline, 1_000_000_000))
        if not ready:
            remaining(deadline)
            continue
        # A raised handler can hide a committed read result. This legacy
        # compatibility entry stops; counted reception uses durable C receipts.
        chunk = os.read(fd, min(size - len(data), 65536))
        if not chunk:
            return bytes(data), False
        data.extend(chunk)
    return bytes(data), True


def deliver(fd, data):
    view = memoryview(data)
    while view:
        # CPython retries EINTR when a handler returns. If a handler raises,
        # write may already have committed a prefix before Python dispatches
        # that exception. Repeating the same view would duplicate those bytes.
        n = os.write(fd, view)
        if n <= 0:
            raise BrokenPipeError('Canal de saída sem progresso')
        view = view[n:]


class Database:
    @property
    def state(self):
        if getattr(self,'_closed',False):
            raise RuntimeError('Database is closed')
        root = getattr(self, '_published_root', None)
        return root.state if root is not None else self._state

    @state.setter
    def state(self, value):
        if getattr(self, '_published_root', None) is not None:
            raise RuntimeError('Only the retained C root may publish this instance')
        self._state = value

    def bind_request_completion(self, completion, *, instrument_deadline_ns):
        """Trusted entry hook for an already-open, complete request scope.

        The entry must cover initialization/framing and pass the same scope to
        native execution. The current CLI does not yet establish that profile.
        This hook never opens a replacement scope or clears INCOMPLETE.
        """
        if type(instrument_deadline_ns) is not int or instrument_deadline_ns < 0:
            raise ValueError('An exact instrument cleanup deadline is required')
        if getattr(self, '_request_completion', None) is not None:
            raise RuntimeError('A serial request already owns a completion scope')
        previous = getattr(self, '_last_completion', None)
        if previous is not None and not previous.completed:
            raise RuntimeError('The previous request has no durable completion')
        root = getattr(self, '_published_root', None)
        if (completion.prepared is not None or completion.state != self.state
                or completion.monitor.ceiling != self.limits['memoria']
                or (root is not None and completion.root is not root)):
            raise ValueError('Completion scope/root does not belong to this instance')
        if any(not callable(getattr(self.modules[name], 'run_accounted', None))
               for name in ('decode', 'authenticate')):
            raise IncompleteIntegration('Native decoder field integration is required before binding')
        self._published_root = completion.root
        # The retained C root now owns the published bytes. Keeping the old
        # Python slot would retain a superseded state after later publication.
        self._state = None
        self._request_completion = (completion, instrument_deadline_ns)

    def __init__(self, environment: Environment, toolchain,*,loading_runtime=None,lifecycle_runtime=None):
        self._closed = False
        prepare_entry()
        self.loading_runtime=LoadingRuntime.current() if loading_runtime is None else loading_runtime
        self.lifecycle_runtime=LifecycleRuntime.current() if lifecycle_runtime is None else lifecycle_runtime
        self._request_libraries=LibraryScope()
        self.environment, self.toolchain = environment, toolchain
        self.modules = {}
        self.state = b''
        self.last_failure = None
        self.directory = tempfile.TemporaryDirectory(prefix='jaydb2-')
        root = Path(self.directory.name)
        try:
            self.runtime = environment.materialize_tooling(root / 'runtime')
            # No requests are accepted and no state exists before the exact
            # initialization proof and configuration have both been checked.
            deadline = CLOCK_END_NS
            for purpose in ('initialize', 'decode', 'authenticate'):
                directory = root / purpose
                directory.mkdir(mode=0o700)
                module, limits = build(environment, directory, purpose, toolchain,
                    deadline=deadline,
                    memory=self.limits['memoria'] if self.modules else ALLOCATION_DOMAIN_BYTES,
                    tools_root=self.runtime,loading_runtime=self.loading_runtime,lifecycle_runtime=self.lifecycle_runtime)
                if self.modules and limits != self.limits:
                    module.close()
                    raise RuntimeError('A configuração mudou durante a inicialização')
                self.modules[purpose], self.limits = module, limits
            initial_module = self.modules.pop('initialize')
            try:
                result = initial_module.run(b'', capacity=self.limits['estado'] + 1,
                    memory=self.limits['memoria'], timeout_ns=remaining(deadline), setup_deadline_ns=deadline)
            finally:
                initial_module.close()
            if result[:1] != b'\1':
                raise RuntimeError('Configuração inicial inválida')
            # Initial seed compilation artifacts are no longer needed and can
            # contain the administrator's initial data. Remove them before use.
            shutil.rmtree(root / 'initialize')
            self.state = result[1:]
        except BaseException:
            self.close()
            raise

    def close(self):
        self._closed=True
        failure=None
        # Keep an owner if its actual close failed, so another cleanup attempt
        # can release it. Independent owners must still receive cleanup.
        try:
            for name in tuple(self.modules):
                try:
                    self.modules[name].close()
                    del self.modules[name]
                except BaseException as error:
                    if failure is None:failure=error
        except BaseException as error:
            if failure is None:failure=error
        try:
            self._close_request_libraries()
        except BaseException as error:
            if failure is None:failure=error
        try:
            self.directory.cleanup()
        except BaseException as error:
            if failure is None:failure=error
        root = getattr(self, '_published_root', None)
        try:
            if root is not None:root.close()
        except BaseException as error:
            if failure is None:failure=error
        finally:
            if root is None or root.cleanup_complete:
                self._published_root=None
            self._request_completion=None
            self._active_request_completion=None
            self._last_completion=None
            self._request_epoch_module=None
            self._state=None
            self.last_failure=None
            self.environment=None
            self.toolchain=None
            self.runtime=None
        if failure is not None:
            raise failure

    def preprocess(self, stage, data, deadline):
        if getattr(self,'_closed',False):
            raise RuntimeError('Database is closed')
        result = self._run_module(self.modules[stage], data, capacity=self.limits['memoria'],
            memory=self.limits['memoria'], timeout_ns=remaining(deadline), setup_deadline_ns=deadline)
        remaining(deadline)
        if not result or result[0] not in (0, 1):
            raise RuntimeError('Transporte interno inválido no pré-processamento')
        return result

    def _run_module(self, module, data, **options):
        active = getattr(self, '_active_request_completion', None)
        if active is None:
            return module.run(data, **options)
        run = getattr(module, 'run_accounted', None)
        if not callable(run):
            raise IncompleteIntegration('The selected native module lacks field accounting')
        if options.get('execution_ns') is not None:
            # Retain before entering the adapter, including when its finally
            # cannot allocate/read any diagnostic or return an assigned value.
            self._request_epoch_module=module
        try:
            return run(data, accounting=active.monitor, **options)
        finally:
            # The private ABI retains the ORIGINAL final/interrupted stage
            # epoch, even when no Python return value was assigned. Only the
            # execute module may move from the verification epoch into a new
            # execution/preparation stage; auth receipts must never be reused.
            if options.get('execution_ns') is not None:
                self._require_request_epoch()

    def request(self, body, *, framing_deadline=None):
        if getattr(self,'_closed',False):
            raise RuntimeError('Database is closed')
        if getattr(self,'_request_libraries',None) is None:
            self._request_libraries=LibraryScope()
        self._require_resolved_ownership()
        self._request_epoch_module=None
        binding = getattr(self, '_request_completion', None)
        if getattr(self, '_published_root', None) is not None and binding is None:
            raise RuntimeError('This instance requires a fresh request completion scope')
        self._request_completion = None
        if binding is not None:
            self._last_completion = binding[0]
        self._active_request_completion = binding[0] if binding is not None else None
        try:
            proposal = self._propose_request(body, framing_deadline=framing_deadline)
        finally:
            self._active_request_completion = None
        # Independent of every cleanup loop and OUTSIDE the proposal's error
        # mapper. An exception while inspecting the registry also escapes;
        # it cannot authorize a fallback response or a publication.
        self._require_resolved_ownership()
        self._require_request_epoch()
        # Deliberately outside the proposal's error mapper. A post-store FFI,
        # release or delivery failure cannot replace an already-completed
        # response, nor turn publication into rollback.
        if binding is not None:
            completion, instrument_deadline = binding
            return completion.finish(proposal.response, state=proposal.state,
                deadline_ns=(proposal.deadline_ns if self._request_native_deadline is None
                             else self._request_native_deadline),
                instrument_deadline_ns=instrument_deadline)
        # Experimental compatibility entry; the CLI still lacks complete
        # startup/framing/accounting integration. Its limits are documented.
        if proposal.state is not None:
            self.state = proposal.state
        return proposal.response

    def _require_resolved_ownership(self):
        runtime=getattr(self,'lifecycle_runtime',None)
        if runtime is not None and (runtime.live_processes or runtime.live_leases):
            raise IncompleteIntegration('Request still owns unresolved helper/output resources')
        scope=getattr(self,'_request_libraries',None)
        if scope is not None and scope.live_owners:
            raise IncompleteIntegration('Request still owns unresolved temporary libraries')

    def _close_request_libraries(self):
        scope=getattr(self,'_request_libraries',None)
        if scope is None:return
        runtime=getattr(self,'lifecycle_runtime',None)
        failure=None
        for owner in scope.live_owners:
            try:
                if runtime is not None:
                    for lease in runtime.live_leases:
                        if lease.library_owner is owner:lease.release()
                    if runtime.has_live_leases(owner):
                        raise IncompleteIntegration('Temporary library still owns output')
                owner.close()
            except BaseException as error:
                if failure is None:failure=error
        if failure is not None:raise failure
        if scope.live_owners:
            raise IncompleteIntegration('Temporary library cleanup remains unresolved')

    def _require_request_epoch(self):
        module=getattr(self,'_request_epoch_module',None)
        if module is None:return
        authority=getattr(module,'last_accounted_epoch',None)
        if authority is not None:
            epoch=authority.deadline_ns()
        else:
            # Compatibility for host-only fixtures. The production adapter
            # installs its raw authority BEFORE any native invocation.
            receipt=getattr(module,'last_accounted_receipt',None)
            epoch=(receipt.decision_deadline_ns if receipt is not None and receipt.timing_flags&1
                   else None)
        if epoch is not None:
            if type(epoch) is not int or epoch<0:
                raise IncompleteIntegration('Native original stage epoch is invalid')
            self._request_native_deadline=epoch

    def _propose_request(self, body, *, framing_deadline=None):
        self.last_failure = None
        self._request_native_deadline=None
        deadline = (time.monotonic_ns() + self.limits['enquadramento']
                    if framing_deadline is None else framing_deadline)
        def prepared(response, state=None):
            epoch=self._request_native_deadline
            return RequestProposal(response,state,deadline if epoch is None else epoch)
        try:
            data = packet(self.state, body)
            decoded = self.preprocess('decode', data, deadline)
            if decoded[0] == 0:
                return prepared(decoded[1:])
            deadline = time.monotonic_ns() + self.limits['autenticacao']
            auth = self.preprocess('authenticate', data, deadline)
            if auth[0] == 0:
                return prepared(auth[1:])
            rest = auth[1:]
            code, rest = split(rest)
            proof, rest = split(rest)
            instance, bindings = split(rest)
            remaining(deadline)
            deadline = time.monotonic_ns() + self.limits['verificacao']
            with tempfile.TemporaryDirectory(prefix='request-', dir=self.directory.name) as temp:
                module, limits = build(self.environment, Path(temp), 'execute', self.toolchain,
                    deadline=deadline, memory=self.limits['memoria'], metadata=(code, proof, instance, bindings),
                    tools_root=self.runtime,
                    loading_runtime=getattr(self,'loading_runtime',None),
                    lifecycle_runtime=getattr(self,'lifecycle_runtime',None),
                    library_scope=self._request_libraries,
                    memory_window=(self._active_request_completion.monitor
                                   if self._active_request_completion is not None else None))
                failure=None
                try:
                    if limits != self.limits:
                        raise RuntimeError('Configuração da requisição divergente')
                    result = self._run_module(module, data, capacity=self.limits['estado'] + self.limits['resposta'] + 17,
                        memory=self.limits['memoria'], timeout_ns=remaining(deadline),
                        execution_ns=self.limits['execucao'], preparation_ns=self.limits['preparacao'],
                        setup_deadline_ns=deadline)
                    preparation_deadline = module.preparation_deadline
                    if result[:1] == b'\1':
                        state, response = split(result[1:])
                    elif result[:1] == b'\0':
                        state, response = None, result[1:]
                    else:
                        raise RuntimeError('Sinal de publicação inválido')
                    if (state is not None and len(state) > self.limits['estado']) or len(response) < 8:
                        raise RuntimeError('Resultado privado inválido')
                    if int.from_bytes(response[:8], 'big') != len(response) - 8 or len(response) - 8 > self.limits['resposta']:
                        raise RuntimeError('Resposta preparada inválida')
                except BaseException as error:
                    failure=error
                    raise
                finally:
                    try:
                        module.close()
                    except BaseException as cleanup:
                        if failure is not None and not isinstance(cleanup,NativeOwnershipPending):
                            # Retain the primary cause; the ownership guard
                            # still refuses completion if cleanup is pending.
                            raise failure from cleanup
                        raise
            # Cleanup which can fail also precedes publication. Once assigned,
            # only delivery remains; its failure must never manufacture rollback.
            if type(preparation_deadline) is not int or preparation_deadline < 0:
                raise RuntimeError('Native preparation epoch was not established')
            deadline = preparation_deadline
            remaining(deadline)
            return prepared(response, state)
        except (StageTimeout, StageMemory):
            self.last_failure = {'code': 'STAGE_RESOURCE'}
            return prepared(error_frame('limite'))
        except NativeFailure as e:
            self.last_failure = {'code': 'NATIVE', 'status': e.status, 'runtime_code': e.runtime_code, 'stage': e.stage}
            if e.status == 3:
                return prepared(error_frame('limite'))
            # The current backend's memory guard is a capacity-allocation
            # failure, not evidence of the contract's consumed-memory measure.
            # Do not fabricate a Medicao above the configured ceiling.
            return prepared(error_frame('falha'))
        except CompileFailure as e:
            self.last_failure = e.detail
            # The host supplied this same absolute deadline before admission.
            # Exhaustion of a model/normalizer budget is retried internally;
            # reaching the stage's real clock deadline is a resource result.
            if e.detail.get('code') == 'HOST_VERIFICATION_DEADLINE':
                return prepared(error_frame('limite'))
            refused = {'IMPORT', 'IMPORT_CYCLE', 'DEPENDENCY', 'PARSE', 'META', 'UNSAFE', 'FOREIGN', 'IO',
                'OPEN_LAW', 'SHADOW', 'REDEFINITION', 'PRIMARY_CHECK', 'BENDTT_CHECK', 'TARGET',
                'SOURCE_BINDING', 'HOST_CAPTURE', 'KERNEL_CAPTURE'}
            return prepared(error_frame('certificado' if e.detail.get('code') in refused else 'falha'))
        except (OSError, MemoryError, RuntimeError) as e:
            self.last_failure = {'code': type(e).__name__, 'message': str(e)}
            return prepared(error_frame('falha'))

    def serve(self, input_fd=0, output_fd=1):
        if getattr(self,'_closed',False):
            raise RuntimeError('Database is closed')
        if getattr(self, '_published_root', None) is not None:
            raise IncompleteIntegration('The counted entry must establish framing and request scopes')
        while True:
            # Between calls there is no active framing stage. EOF and an
            # operator stop here end the instance without inventing a request.
            first = os.read(input_fd, 1)
            if not first:
                return
            deadline = time.monotonic_ns() + self.limits['enquadramento']
            try:
                rest, complete = exact_read(input_fd, 7, deadline)
                header = first + rest
                if not complete:
                    deliver(output_fd, error_frame('entrada'))
                    return
                n = int.from_bytes(header, 'big')
                if n > self.limits['mensagem']:
                    deliver(output_fd, error_frame('limite'))
                    return
                body, complete = exact_read(input_fd, n, deadline)
                if not complete:
                    deliver(output_fd, error_frame('entrada'))
                    return
                response = self.request(body, framing_deadline=deadline)
            except StageTimeout:
                deliver(output_fd, error_frame('limite'))
                return
            deliver(output_fd, response)
